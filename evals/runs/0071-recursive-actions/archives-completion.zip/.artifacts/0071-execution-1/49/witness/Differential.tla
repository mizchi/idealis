---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x

Init == x=0
Next == \E delta \in {1}: LET RECURSIVE Down(_) Down(n) == IF n=0 THEN x'=(x+delta)%5 ELSE Down(n-1) IN Down(3)
Safe == x<4

VARIABLE __position
__TraceInit == Init /\ __position = 0 /\ (x = 0)
__TraceNext == ((__position = 0 /\ __position' = 1 /\ (x' = 1)) \/ (__position = 1 /\ __position' = 2 /\ (x' = 2)) \/ (__position = 2 /\ __position' = 3 /\ (x' = 3)) \/ (__position = 3 /\ __position' = 4 /\ (x' = 4)) \/ (__position = 4 /\ __position' = 4 /\ (x' = 4))) /\ (Next \/ UNCHANGED <<x>>)
__TraceSpec == __TraceInit /\ [][__TraceNext]_<<x,__position>> /\ WF_<<x,__position>>(__TraceNext)
__Expected == <>(~(Safe))
====