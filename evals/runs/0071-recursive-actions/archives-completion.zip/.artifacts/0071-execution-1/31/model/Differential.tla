---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
RECURSIVE Down(_)
Down(n) == IF n=0 THEN x'=(x+1)%4 ELSE Down(n-1)
Init == x=0
Next == Down(2)
Safe == x<3
====