---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x
RECURSIVE Down(_), Other(_)
Down(n) == IF n=0 THEN x'=(x+1)%3 ELSE Other(n-1)
Other(n) == Down(n)
Init == x=0
Next == Down(4)
Safe == TRUE
====