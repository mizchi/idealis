---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x

Init == x=0
Next == \E delta \in 1..2: LET RECURSIVE Down(_) Down(n) == IF n=0 THEN x'=(x+delta)%3 ELSE Down(n-1) IN Down(3)
Safe == TRUE
====