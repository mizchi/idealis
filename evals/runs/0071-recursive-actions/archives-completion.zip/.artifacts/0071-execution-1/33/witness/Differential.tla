---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
RECURSIVE Apply(_,_)
Apply(F(_),n) == IF n=0 THEN F((x+1)%6) ELSE Apply(F,n-1)
Assign(v) == x'=v
Init == x=0
Next == Apply(Assign,6)
Safe == x<5

VARIABLE __position
__TraceInit == Init /\ __position = 0 /\ (x = 0)
__TraceNext == ((__position = 0 /\ __position' = 1 /\ (x' = 1)) \/ (__position = 1 /\ __position' = 2 /\ (x' = 2)) \/ (__position = 2 /\ __position' = 3 /\ (x' = 3)) \/ (__position = 3 /\ __position' = 4 /\ (x' = 4)) \/ (__position = 4 /\ __position' = 5 /\ (x' = 5)) \/ (__position = 5 /\ __position' = 5 /\ (x' = 5))) /\ (Next \/ UNCHANGED <<x>>)
__TraceSpec == __TraceInit /\ [][__TraceNext]_<<x,__position>> /\ WF_<<x,__position>>(__TraceNext)
__Expected == <>(~(Safe))
====