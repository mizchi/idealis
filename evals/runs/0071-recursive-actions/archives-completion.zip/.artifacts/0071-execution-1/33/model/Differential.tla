---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
RECURSIVE Apply(_,_)
Apply(F(_),n) == IF n=0 THEN F((x+1)%6) ELSE Apply(F,n-1)
Assign(v) == x'=v
Init == x=0
Next == Apply(Assign,6)
Safe == x<5
====