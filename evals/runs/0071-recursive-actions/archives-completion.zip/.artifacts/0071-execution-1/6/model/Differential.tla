---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x,y
RECURSIVE Down(_)
Down(n) == IF n=0 THEN x'=(x+1)%3 ELSE Down(n-1)
Init == x=0 /\ y=0
Next == \E choice \in {0,1}: Down(3) /\ y'=choice /\ x'=(x+1)%3
Safe == TRUE
====