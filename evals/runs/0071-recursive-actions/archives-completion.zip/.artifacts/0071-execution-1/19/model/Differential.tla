---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x
RECURSIVE Down(_)
Down(n) == IF n=0 THEN x'=(x+1)%3 ELSE Down(n-1)
P == [][Down(3)]_x
Init == x=0
Next == Down(3)
Safe == TRUE
====