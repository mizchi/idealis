---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x
RECURSIVE Assign(_,_)
Assign(n,p) == IF n=0 THEN x'=[<<1>> EXCEPT ![1]=@+p][1] ELSE Assign(n-1,p)
Init == x=0
Next == UNCHANGED x
Safe == [<<2>> EXCEPT ![1]=ENABLED (x'=3 /\ Assign(2,@))][1]
====