---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x,y
Outer(v) == LET RECURSIVE Keep(_) Keep(n) == IF n=0 THEN UNCHANGED v ELSE Keep(n-1) IN Keep(3)
Init == x=0 /\ y=7
Next == (\E delta \in 1..2: x'=(x+delta)%3) /\ Outer(y)
Safe == y=7
====