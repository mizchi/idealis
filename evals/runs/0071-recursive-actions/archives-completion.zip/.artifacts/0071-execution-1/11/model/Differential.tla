---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x
RECURSIVE Write(_,_)
Write(n,k) == IF n=0 THEN x'=[x EXCEPT ![k]=(@+1)%2] ELSE Write(n-1,k)
Init == x = <<0,0>>
Next == \E key \in 1..2: Write(3,key)
Safe == TRUE
====