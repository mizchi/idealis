---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x
RECURSIVE Down(_)
Down(n) == IF n=0 THEN x'=(x+1)%3 ELSE Down(n-1)
Apply(A(_), n) == A(n)
Init == x=0
Next == Apply(Down,4)
Safe == TRUE
====