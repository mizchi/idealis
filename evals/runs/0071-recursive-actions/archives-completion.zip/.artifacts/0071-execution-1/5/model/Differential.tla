---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x
RECURSIVE Down(_)
Down(n) == IF n=0 THEN (\E delta \in 1..2: x'=(x+delta)%3) ELSE Down(n-1) \/ x'=x
Init == x=0
Next == Down(3)
Safe == TRUE
====