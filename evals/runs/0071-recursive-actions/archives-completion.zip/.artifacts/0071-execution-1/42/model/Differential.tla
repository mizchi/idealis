---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
RECURSIVE Down(_)
Down(n) == IF n=0 THEN x'=(x+1)%6 ELSE Down(n-1)
Init == x=0
Next == Down(3)
Safe == x<6
====