---- MODULE Counter ----
EXTENDS Naturals
VARIABLE x
RECURSIVE Down(_)
Down(n) == IF n=0 THEN x'=(x+1)%3 ELSE Down(n-1)
====