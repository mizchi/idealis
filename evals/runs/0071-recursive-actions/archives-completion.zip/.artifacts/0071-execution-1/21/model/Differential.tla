---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x
I == INSTANCE Counter
Down(n) == I!Down(n)
Init == x=0
Next == Down(3)
Safe == TRUE
====