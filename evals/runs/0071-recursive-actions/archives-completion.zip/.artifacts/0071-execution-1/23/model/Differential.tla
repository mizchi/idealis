---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x
RECURSIVE Down(_)
Down(n) == IF n=0 THEN x' \in 0..127 ELSE Down(n-1)
Init == x=0
Next == Down(3)
Safe == TRUE
====