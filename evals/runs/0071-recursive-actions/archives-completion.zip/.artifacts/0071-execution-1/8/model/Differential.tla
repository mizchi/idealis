---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x,y
RECURSIVE Copy(_,_)
Copy(n,p) == IF n=0 THEN y'=p ELSE Copy(n-1,p)
Init == x=0 /\ y=0
Next == x'=(x+1)%3 /\ Copy(3,x')
Safe == x=y
====