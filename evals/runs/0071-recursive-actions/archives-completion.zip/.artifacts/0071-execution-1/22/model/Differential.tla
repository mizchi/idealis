---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x
RECURSIVE Down(_,_,_)
Down(n,a,b) == IF n=0 THEN x'=(x+a+b)%257 ELSE Down(n-1,a,b)
Init == x=0
Next == Down(8,1,1)
Safe == TRUE
====