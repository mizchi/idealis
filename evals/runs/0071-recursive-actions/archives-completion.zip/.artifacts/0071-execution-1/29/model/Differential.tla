---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x

Init == x=0
Next == \E delta \in {1}: LET RECURSIVE Down(_) Down(n) == IF n=0 THEN x'=(x+delta)%4 ELSE Down(n-1) IN Down(5)
Safe == x<3
====