---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x
RECURSIVE Walk(_,_)
Walk(n,acc) == IF n=0 THEN x'=acc ELSE Walk(n-1,[acc EXCEPT ![n]=(@+1)%2])
Init == x = <<0,0>>
Next == Walk(2,x)
Safe == TRUE
====