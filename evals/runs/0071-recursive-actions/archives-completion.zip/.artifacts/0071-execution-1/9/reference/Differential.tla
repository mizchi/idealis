---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x,y
RECURSIVE Keep(_,_)
Keep(v,n) == IF n=0 THEN UNCHANGED v ELSE Keep(v,n-1)
Init == x=0 /\ y=7
Next == (\E delta \in 1..2: x'=(x+delta)%3) /\ Keep(y,3)
Safe == y=7
====