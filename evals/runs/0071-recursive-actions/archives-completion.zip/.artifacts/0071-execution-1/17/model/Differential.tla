---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLES x
RECURSIVE Seed(_)
Seed(n) == IF n=0 THEN x \in {0,1} ELSE Seed(n-1)
Init == Seed(4)
Next == x'=(x+1)%3
Safe == TRUE
====