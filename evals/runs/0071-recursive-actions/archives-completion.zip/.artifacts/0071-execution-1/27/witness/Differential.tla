---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
RECURSIVE Down(_), Other(_)
Down(n) == IF n=0 THEN x'=(x+1)%2 ELSE Other(n-1)
Other(n) == Down(n)
Init == x=0
Next == Down(6)
Safe == x<1

VARIABLE __position
__TraceInit == Init /\ __position = 0 /\ (x = 0)
__TraceNext == ((__position = 0 /\ __position' = 1 /\ (x' = 1)) \/ (__position = 1 /\ __position' = 1 /\ (x' = 1))) /\ (Next \/ UNCHANGED <<x>>)
__TraceSpec == __TraceInit /\ [][__TraceNext]_<<x,__position>> /\ WF_<<x,__position>>(__TraceNext)
__Expected == <>(~(Safe))
====