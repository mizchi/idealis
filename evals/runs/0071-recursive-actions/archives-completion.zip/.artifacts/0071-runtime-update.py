from pathlib import Path
p=Path('crates/rtlc/src/safety_definitions.rs');s=p.read_text().replace('Binding, Branch, Definition, Domain, Expression, SafetyProgram, Step, TemporalFormula,','Binding, BodyKind, Branch, Definition, DefinitionBody, Domain, Expression, SafetyProgram, Step, TemporalFormula,')
s=s.replace('struct DefinitionSignature {\n','struct DefinitionSignature {\n    kind: BodyKind,\n')
s=s.replace('''                    Step::Guard { expression }
''','''                    Step::Call { arguments, captures, .. } => output.extend(arguments.iter().chain(captures)),
                    Step::Guard { expression }
''',1)
start=s.index('        let mut pending = vec![(&definition.body, 0)];');end=s.index('\n    let mut colors',start)
s=s[:start]+'''        enum Node<'a> { Expression(&'a Expression, usize), Branch(&'a Branch, usize) }
        let mut pending = match &definition.body {
            DefinitionBody::Expression(body) if definition.body_kind == BodyKind::Expression => vec![Node::Expression(body, 0)],
            DefinitionBody::Action(branches) if definition.body_kind == BodyKind::Action => branches.iter().map(|branch| Node::Branch(branch, 0)).collect(),
            _ => return Err(invalid("Invalid safety definition body kind")),
        };
        let mut call = |id: usize, arguments: &[Expression], captures: &[Expression], kind| -> Result<(), CoreError> {
            validate_wire_index(id)?;
            let callee = definitions.get(id).ok_or_else(|| invalid("Unknown safety definition ID"))?;
            if callee.body_kind != kind { return Err(invalid("Invalid safety call body kind")); }
            if arguments.len() != callee.parameter_count || captures.len() != callee.capture_count {
                return Err(invalid("Invalid safety call arity or capture count"));
            }
            edges[index].push(id);
            Ok(())
        };
        while let Some(node) = pending.pop() {
            match node {
                Node::Expression(expression, depth) => {
                    if depth > 48 { return Err(invalid("Safety expression nesting exceeds 48")); }
                    if let Expression::Call {definition, arguments, captures} = expression {
                        call(*definition, arguments, captures, BodyKind::Expression)?;
                    }
                    if let Expression::Enabled {branches, subscript} = expression {
                        pending.extend(branches.iter().map(|branch| Node::Branch(branch, depth + 1)));
                        pending.extend(subscript.iter().map(|body| Node::Expression(body, depth + 1)));
                    } else {
                        pending.extend(expression.children().into_iter().map(|body| Node::Expression(body, depth + 1)));
                    }
                }
                Node::Branch(branch, depth) => {
                    if depth > 48 { return Err(invalid("Safety expression nesting exceeds 48")); }
                    for step in &branch.steps {
                        match step {
                            Step::Call {definition, arguments, captures} => {
                                call(*definition, arguments, captures, BodyKind::Action)?;
                                pending.extend(arguments.iter().chain(captures).map(|body| Node::Expression(body, depth + 1)));
                            }
                            Step::Frame {arguments, captures, branches, ..} => {
                                pending.extend(arguments.iter().chain(captures).map(|body| Node::Expression(body, depth + 1)));
                                pending.extend(branches.iter().map(|branch| Node::Branch(branch, depth + 1)));
                            }
                            Step::Guard {expression} | Step::Assign {value: expression, ..} => pending.push(Node::Expression(expression, depth + 1)),
                            Step::Bind {domain, ..} | Step::Choose {domain, ..} => pending.extend(domain.children().into_iter().map(|body| Node::Expression(body, depth + 1))),
                        }
                    }
                }
            }
        }
    }
'''+s[end:]
anchor='''                    Step::Guard { expression } => {
                        summary.merge(self.expression(expression, context)?)
                    }'''
assert anchor in s;s=s.replace(anchor,'''                    Step::Call { definition, arguments, captures } => {
                        summary.merge(self.call(*definition, arguments, captures, BodyKind::Action, context)?);
                    }
'''+anchor)
start=s.index('''                let callee = self
                    .metadata''',s.index('fn expression_uncached'));end=s.index('''            Expression::Parameter { slot } =>''',start)
s=s[:start]+'''                return self.call(*definition, arguments, captures, BodyKind::Expression, context);
            }
'''+s[end:]
anchor='''    fn expression(
        &mut self,''';pos=s.index(anchor)
s=s[:pos]+'''    fn call(&mut self, definition: usize, arguments: &[Expression], captures: &[Expression], kind: BodyKind, context: Context) -> Result<Summary, CoreError> {
        validate_wire_index(definition)?;
        let callee = self.metadata.definitions.get(definition).ok_or_else(|| invalid("Unknown safety definition ID"))?;
        if callee.kind != kind { return Err(invalid("Invalid safety call body kind")); }
        if arguments.len() != callee.parameter_count || captures.len() != callee.capture_count {
            return Err(invalid("Invalid safety call arity or capture count"));
        }
        let required = self.metadata.summaries[definition][context.mode()].clone().ok_or_else(|| invalid("Invalid safety call phase"))?;
        self.actuals(arguments, captures, callee.parameter_count, callee.capture_count, required, context)
    }

'''+s[pos:]
s=s.replace('''                parameter_count: definition.parameter_count,
                capture_count: definition.capture_count,''','''                kind: definition.body_kind,
                parameter_count: definition.parameter_count,
                capture_count: definition.capture_count,''')
s=s.replace('''                    match metadata.expression(&definition.body, context) {''','''                    let result = match &definition.body {
                        DefinitionBody::Expression(body) => metadata.expression(body, context),
                        DefinitionBody::Action(branches) if phase <= 1 => metadata.branches(branches, context).map(|mut summary| { summary.stateful = true; summary }),
                        DefinitionBody::Action(_) => Err(invalid("Invalid safety action definition phase")),
                    };
                    match result {''')
p.write_text(s)
p=Path('crates/rtlc/src/safety_expressions.rs');s=p.read_text().replace('use crate::ir::{Binding, Branch, Domain, Expression, FoldOrder, Scalar, Step};','use crate::ir::{Binding, Branch, DefinitionBody, Domain, Expression, FoldOrder, Scalar, Step};')
s=s.replace('''                    Step::Guard { expression }
''','''                    Step::Call { arguments, captures, .. } => {
                        for expression in arguments.iter().chain(captures) { visitor(expression); }
                    }
                    Step::Guard { expression }
''',1)
s=s.replace('''                Step::Frame { .. } => {
                    return Err''','''                Step::Frame { .. } | Step::Call { .. } => {
                    return Err''',1)
s=s.replace('''                evaluate(
                    &definition.body,
''','''                let DefinitionBody::Expression(body) = &definition.body else {
                    return Err(CoreError::protocol("Invalid safety call body kind"));
                };
                evaluate(
                    body,
''',1)
anchor='''    match step {
        Step::Frame {''';assert anchor in s
s=s.replace(anchor,'''    match step {
        Step::Call { definition, arguments, captures } => {
            arena.consume(1)?;
            let definition = arena.definitions.get(*definition).ok_or_else(|| CoreError::protocol("Unknown safety definition"))?;
            let DefinitionBody::Action(branches) = &definition.body else {
                return Err(CoreError::protocol("Invalid safety call body kind"));
            };
            let frame = CallFrame::new(arguments, captures, context);
            let inner = EvalContext {
                recursive: ctx.recursive || definition.recursive,
                locals: &[], frame: Some(&frame), old: None, ..ctx
            };
            for inner_branch in branches {
                if visit_branch(inner_branch, 0, inner, next, arena, &mut |next, arena| {
                    visit_branch(branch, position + 1, ctx, next, arena, visitor)
                })? { return Ok(true); }
            }
            Ok(false)
        }
        Step::Frame {''',1)
p.write_text(s)
p=Path('crates/rtlc/src/safety_prepared.rs');s=p.read_text().replace('''        roots.extend(
            program
                .definitions
                .iter()
                .flatten()
                .map(|definition| &definition.body),
        );''','''        for definition in program.definitions.iter().flatten() {
            match &definition.body {
                crate::ir::DefinitionBody::Expression(body) => roots.push(body),
                crate::ir::DefinitionBody::Action(branches) => register_branch_memberships(branches, &mut |expression| roots.push(expression)),
            }
        }''');p.write_text(s)
p=Path('crates/rtlc/src/safety.rs');s=p.read_text().replace('''            arena.register_memberships(&definition.body);''','''            match &definition.body {
                crate::ir::DefinitionBody::Expression(body) => arena.register_memberships(body),
                crate::ir::DefinitionBody::Action(branches) => arena.register_branches(branches),
            }''');p.write_text(s)
p=Path('crates/rtlc/src/bounded_drop.rs');s=p.read_text().replace('''    match step {
        Step::Frame {''','''    match step {
        Step::Call { arguments, captures, .. } => {
            dispose_expressions(mem::take(arguments), budget, worklist);
            dispose_expressions(mem::take(captures), budget, worklist);
        }
        Step::Frame {''');p.write_text(s)
for path in ['crates/rtlc/src/ir.rs','crates/rtlc/src/safety_parallel.rs','crates/rtlc/src/safety_symmetry.rs']:
 p=Path(path);s=p.read_text().replace('Step::Frame { .. } =>', 'Step::Frame { .. } | Step::Call { .. } =>').replace('Step::Frame { .. } | Step::Bind { .. } | Step::Choose { .. } =>','Step::Frame { .. } | Step::Call { .. } | Step::Bind { .. } | Step::Choose { .. } =>');p.write_text(s)
