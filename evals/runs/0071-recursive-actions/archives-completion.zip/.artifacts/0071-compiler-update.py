from pathlib import Path
p=Path('crates/rtla-compiler/src/analysis.rs');s=p.read_text();s=s.replace("    Definition(&'a ir::Definition),", "    Definition(&'a ir::Definition),\n    Body(&'a ir::DefinitionBody),");s=s.replace("    Definition(&'a mut ir::Definition),", "    Definition(&'a mut ir::Definition),\n    Body(&'a mut ir::DefinitionBody),")
s=s.replace('''            "ir-step" if constructor == "frame" => {''','''            "ir-step" if constructor == "call" => {
                if p.starts_with("arguments") { result.role = "call-actual"; }
                else if p.starts_with("captures") { result.role = "call-capture"; }
                else { result.role = "call-edge"; result.scope = "definition"; }
            }
            "ir-step" if constructor == "frame" => {''')
anchor='''        match value {
            ir::Step::Bind {''';assert anchor in s
s=s.replace(anchor,'''        match value {
            ir::Step::Call { definition, arguments, captures } => arguments.$iter()
                .map(|value| $edge($node::Expression(value), "ir-step", "call", "", "arguments[*]"))
                .chain(captures.$iter().map(|value| $edge($node::Expression(value), "ir-step", "call", "", "captures[*]")))
                .chain([$edge($node::Call(definition), "ir-step", "call", "", "definition")]).collect(),
            ir::Step::Bind {''',1)
anchor='''        vec![$edge(
            $node::Expression(body),
            "ir-definition",
            "definition",
            "",
            "body",
        )]''';assert anchor in s
s=s.replace(anchor,'''        match body {
            ir::DefinitionBody::Expression(body) => vec![$edge($node::Expression(body), "ir-definition", "definition", "", "body")],
            ir::DefinitionBody::Action(branches) => branches.$iter().map(|branch| $edge($node::Branch(branch), "ir-definition", "definition", "", "body[*]")).collect(),
        }''')
s=s.replace('''        Node::Definition(value) => ir_wrapper_edges!(Definition, value, Node, edge, iter),''','''        Node::Body(body) => match body {
            ir::DefinitionBody::Expression(body) => vec![edge(Node::Expression(body), "ir-body", "expression", "", "body")],
            ir::DefinitionBody::Action(branches) => branches.iter().map(|branch| edge(Node::Branch(branch), "ir-body", "action", "", "body[*]")).collect(),
        },
        Node::Definition(value) => ir_wrapper_edges!(Definition, value, Node, edge, iter),''')
s=s.replace('''            Self::Definition(value) => Node::Definition(value),''','''            Self::Definition(value) => Node::Definition(value),
            Self::Body(value) => Node::Body(value),''')
s=s.replace('''            Self::Definition(value) => NodeMut::Definition(value),''','''            Self::Definition(value) => NodeMut::Definition(value),
            Self::Body(value) => NodeMut::Body(value),''')
s=s.replace('''        NodeMut::Definition(value) => {
            ir_wrapper_edges!''','''        NodeMut::Body(body) => match body {
            ir::DefinitionBody::Expression(body) => vec![edge_mut(NodeMut::Expression(body), "ir-body", "expression", "", "body")],
            ir::DefinitionBody::Action(branches) => branches.iter_mut().map(|branch| edge_mut(NodeMut::Branch(branch), "ir-body", "action", "", "body[*]")).collect(),
        },
        NodeMut::Definition(value) => {
            ir_wrapper_edges!''')
s=s.replace('''        body: I::Old,
''','''        body: I::Old.into(),
''');p.write_text(s)
p=Path('crates/rtla-compiler/src/typed.rs');s=p.read_text().replace('''            Node::Expression(I::Call { definition, .. }) => {''','''            Node::Expression(I::Call { definition, .. }) | Node::Step(Step::Call { definition, .. }) => {''')
s=s.replace('''        if let NodeMut::Expression(I::Call {
            definition,
            captures,
            ..
        }) = node''','''        if let NodeMut::Expression(I::Call { definition, captures, .. }) | NodeMut::Step(Step::Call { definition, captures, .. }) = node''');p.write_text(s)
p=Path('crates/rtla-compiler/src/lib.rs');s=p.read_text().replace('key: (usize, u8, bool, Vec<Target>),','key: (usize, u8, bool, Vec<Target>, bool),')
s=s.replace('''Node::Expression(body), &self.level_cache.borrow()''','''Node::Body(body), &self.level_cache.borrow()''')
s=s.replace('''                let summary =
                    typed::level_summary(Node::Body(body), &self.level_cache.borrow());''','''                let mut summary = typed::level_summary(Node::Body(body), &self.level_cache.borrow());
                if self.shared[*id].key.4 { summary.base = summary.base.max(if self.shared[*id].key.1 == 1 { 1 } else { 2 }); }''')
# Keep the expression call API unchanged and share its registration machinery with action calls.
start=s.index('    fn shared_arguments_ir(');body=s.index('        let entry =',start)
header=s[start:body];new=header.replace('mut targets:', 'targets:')+'''        self.shared_body_ir(name, arguments, context, membership, targets, false)
    }
    fn shared_body_ir(
        &mut self, name: &str, arguments: Vec<ir::Expression>, context: &Context,
        membership: bool, mut targets: BTreeMap<usize, Target>, action: bool,
    ) -> Result<ir::Expression> {
''';s=s[:start]+new+s[body:]
s=s.replace('''        let required = self.requirements(name, context, false)?;''','''        let required = self.requirements(name, context, action)?;''',1)
s=s.replace('''        let key = (position, phase, membership, signature);''','''        let key = (position, phase, membership, signature, action);''')
s=s.replace('''            let lowered = if membership {
                self.membership_ir(&body, &context)?
            } else {
                self.expression_ir(&body, &context)?
            };
            let body = lowered;''','''            let body = if self.shared[id].key.4 {
                ir::DefinitionBody::Action(self.action_ir(&body, &context, "<action>")?)
            } else if membership {
                self.membership_ir(&body, &context)?.into()
            } else {
                self.expression_ir(&body, &context)?.into()
            };''')
s=s.replace('''                body_kind: ir::BodyKind::Expression,
                local_scope: typed::local_scope(Node::Expression(&body)),''','''                body_kind: if self.shared[id].key.4 { ir::BodyKind::Action } else { ir::BodyKind::Expression },
                local_scope: typed::local_scope(Node::Body(&body)),''')
s=s.replace('''NodeMut::Expression(
                    &mut entry.definition.as_mut().unwrap().body,''','''NodeMut::Body(
                    &mut entry.definition.as_mut().unwrap().body,''')
s=s.replace('''typed::capture_slots(Node::Expression(
                        &entry.definition.as_ref().unwrap().body,''','''typed::capture_slots(Node::Body(
                        &entry.definition.as_ref().unwrap().body,''')
s=s.replace('''NodeMut::Expression(&mut definition.body)''','''NodeMut::Body(&mut definition.body)''')
s=s.replace('''Node::Expression(&entry.definition.as_ref().unwrap().body)''','''Node::Body(&entry.definition.as_ref().unwrap().body)''')
s=s.replace('''typed::call_ids(Node::Expression(
                    &entry.definition.as_ref().unwrap().body,''','''typed::call_ids(Node::Body(
                    &entry.definition.as_ref().unwrap().body,''')
p.write_text(s)
p=Path('crates/rtla-compiler/src/typed_lower.rs');s=p.read_text();anchor='''        let (body, expanded) = self.call(name, args, context)?;
        let branches = self.action_ir(&body, &expanded, name)?;''';assert s.count(anchor)==1
s=s.replace(anchor,'''        if self.scopes[context.scope][name].definition.is_recursive {
            let child = context.nested()?;
            let arguments = args.iter().map(|value| self.expression_ir(value, &child)).collect::<Result<Vec<_>>>()?;
            let targets = self.call_targets(name, args, context)?;
            let I::Call { definition, arguments, captures } = self.shared_body_ir(name, arguments, context, false, targets, true)? else { unreachable!() };
            return Ok(vec![branch(name, vec![Step::Call { definition, arguments, captures }])]);
        }
'''+anchor)
p.write_text(s)
# Existing expression definition literals only need a conversion at the construction boundary.
for path in ['crates/rtlc/tests/deep_drop.rs','crates/rtlc/tests/deep_drop_paths.rs','crates/rtlc/tests/drop_allocations.rs','crates/rtlc/tests/drop_budget.rs','crates/idealis-core/tests/deep_request_drop.rs']:
 p=Path(path);s=p.read_text();s=s.replace('''        body,
    }''','''        body: body.into(),
    }''');s=s.replace('''            body: expression,
''','''            body: expression.into(),
''');p.write_text(s)
# Remove traversal functions superseded by the typed graph walk.
p=Path('crates/rtlc/src/safety_definitions.rs');s=p.read_text();start=s.index("fn branch_children<'a>");end=s.index('fn definition_order',start);s=s[:start]+s[end:];p.write_text(s)
