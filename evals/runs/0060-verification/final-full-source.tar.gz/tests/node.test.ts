import { test } from "node:test";
import { registerAdvancedContract } from "./advanced-contract.js";
import { registerAsyncContract } from "./async-contract.js";
import { registerBackendContract } from "./backend-contract.js";
import { registerBudgetContract } from "./budget-contract.js";
import { registerContract } from "./contract.js";
import { registerEvalLoopContract } from "./eval-loop-contract.js";
import { registerEvaluationContract } from "./evaluation-contract.js";
import { registerIntegrationContract } from "./integration-contract.js";
import { registerPortableContract } from "./portable-contract.js";
import { registerPropertyContract } from "./property-contract.js";
import { registerSafetyContract } from "./safety-contract.js";
import { registerSchedulingContract } from "./scheduling-contract.js";
import { registerShardingContract } from "./sharding-contract.js";
import { registerSourceContract } from "./source-contract.js";
import { registerUsableContract } from "./usable-contract.js";

registerContract((name, run) => {
  test(name, run);
});
registerSourceContract((name, run) => {
  test(name, run);
});
registerBackendContract((name, run) => {
  test(name, run);
});
registerAdvancedContract((name, run) => {
  test(name, run);
});
registerPropertyContract((name, run) => {
  test(name, run);
});
registerIntegrationContract((name, run) => {
  test(name, run);
});
registerEvaluationContract((name, run) => {
  test(name, run);
});
registerEvalLoopContract((name, run) => {
  test(name, run);
});
registerBudgetContract((name, run) => {
  test(name, run);
});
registerShardingContract((name, run) => {
  test(name, run);
});
registerPortableContract((name, run) => {
  test(name, run);
});
registerUsableContract((name, run) => {
  test(name, run);
});
registerAsyncContract((name, run) => {
  test(name, run);
});
registerSafetyContract((name, run) => {
  test(name, run);
});
registerSchedulingContract((name, run) => {
  test(name, run);
});
