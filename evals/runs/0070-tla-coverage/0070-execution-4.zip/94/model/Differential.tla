---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Op(value) == label:: x'=value
Init == x = 0
Next == Op((x+1)%3)!label
Safe == x=0
====