---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
RECURSIVE Sum(_)
Sum(value) == IF value=0 THEN 0 ELSE value+Sum(value-1)
Init == x=3
Next == x'=IF x=3 THEN Sum(x) ELSE x
Safe == x=3 \/ x=6
====