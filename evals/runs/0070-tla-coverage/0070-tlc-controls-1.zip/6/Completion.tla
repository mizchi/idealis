---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Op(value) == IF value=0 THEN 10 ELSE 20
Init == x=Op(0)!2
Next == UNCHANGED x
Safe == x=10
====