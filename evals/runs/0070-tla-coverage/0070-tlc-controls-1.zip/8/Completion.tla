---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Op == \A bound \in 0..2: bound+1
Init == x=Op!(2)
Next == UNCHANGED x
Safe == x=3
====