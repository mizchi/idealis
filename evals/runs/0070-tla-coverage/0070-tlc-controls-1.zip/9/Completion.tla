---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Op == \A bound \in 0..2: bound+1
Apply(F(_), value) == F(value)
Init == x=Apply(Op!@,2)
Next == UNCHANGED x
Safe == x=3
====