---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Fn[value \in 0..1] == IF value=0 THEN 0 ELSE Fn[1]
Init == x=Fn[0]
Next == UNCHANGED x
Safe == x=0
====