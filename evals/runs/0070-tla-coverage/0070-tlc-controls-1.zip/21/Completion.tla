---- MODULE Completion ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x
Apply(F(_), value) == F(value)
Update(value) == [<<1>> EXCEPT ![1]=@+value]
Init == x=[<<2>> EXCEPT ![1]=Apply(Update,@)[1]]
Next == UNCHANGED x
Safe == x=<<3>>
====