---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Fn[<<left,right>> \in {<<0,1>>, <<1,1>>, <<2,1>>}] == IF left=0 THEN right ELSE Fn[<<left-1,right>>]+1
Init == x=Fn[<<2,1>>]
Next == UNCHANGED x
Safe == x=3
====