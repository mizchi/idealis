---- MODULE AnalysisParity ----
EXTENDS Naturals, Integers, Sequences, FiniteSets, Apalache
VARIABLE x
Init == x = 0
Next == UNCHANGED x


Safe == [<<9>> EXCEPT ![1] = LET Inspect(p) == L:: (@ = 9) IN TRUE][1]
====