---- MODULE Completion ----
EXTENDS Naturals, Apalache
VARIABLE x
RECURSIVE Add(_,_)
Add(left,right) == IF right=0 THEN left ELSE Add(left+1,right-1)
Init == x = ApaFoldSeqLeft(Add,0,<<1,2,3>>)
Next == UNCHANGED x
Safe == x=6
====