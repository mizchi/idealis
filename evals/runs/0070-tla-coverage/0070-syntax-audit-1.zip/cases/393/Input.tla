---- MODULE Test ----
<> value == value
====