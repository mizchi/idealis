---- MODULE Test ----
Op == F( ^* )
====