---- MODULE Test ----
DOMAIN value == value
====