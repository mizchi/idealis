---- MODULE Test ----
left \land right == value
====