---- MODULE Test ----
Op == \lnot value
====