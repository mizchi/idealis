---- MODULE Test ----
Op == value ^*
====