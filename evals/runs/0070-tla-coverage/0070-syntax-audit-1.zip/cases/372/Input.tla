---- MODULE Test ----
Op == ~ value
====