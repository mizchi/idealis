---- MODULE Test ----
Op == F( %% )
====