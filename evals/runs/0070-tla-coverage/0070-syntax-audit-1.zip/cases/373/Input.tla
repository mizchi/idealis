---- MODULE Test ----
~ value == value
====