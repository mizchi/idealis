
---- MODULE Test ----
op == STRING
====

