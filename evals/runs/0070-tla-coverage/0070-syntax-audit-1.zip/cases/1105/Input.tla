---- MODULE Test ----
Op == PROOF OBVIOUS
====