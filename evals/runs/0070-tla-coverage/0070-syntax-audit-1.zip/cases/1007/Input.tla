---- MODULE Test ----
Op == F( SUBSET )
====