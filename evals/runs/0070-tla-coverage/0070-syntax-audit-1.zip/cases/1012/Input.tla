---- MODULE Test ----
Op == DOMAIN value
====