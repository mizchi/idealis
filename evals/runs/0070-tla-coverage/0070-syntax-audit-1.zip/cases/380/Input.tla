---- MODULE Test ----
Op == ¬ value
====