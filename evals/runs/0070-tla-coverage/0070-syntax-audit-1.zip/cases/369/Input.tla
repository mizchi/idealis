---- MODULE Test ----
\lnot value == value
====