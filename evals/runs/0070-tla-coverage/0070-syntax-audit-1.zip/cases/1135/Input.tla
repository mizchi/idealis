---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x

Init == x = 0
Next == \E delta \in 1..2: LET C(limit) == INSTANCE Counter WITH Limit <- limit, value <- x IN C(delta)!Next
Safe == x \in 0..2
====