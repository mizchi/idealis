---- MODULE Test ----
Op == [] value
====