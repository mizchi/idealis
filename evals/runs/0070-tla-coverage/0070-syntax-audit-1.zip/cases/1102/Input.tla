---- MODULE Test ----
Op == F((LAMBDA value: value))
====