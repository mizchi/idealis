---- MODULE Test ----
CONSTANT ◇ _
====