
---- MODULE Test ----
op == "(*"
====

