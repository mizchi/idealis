---- MODULE Test ----
Op == F( UNCHANGED )
====