---- MODULE Test ----
CONSTANT _ \land _
====