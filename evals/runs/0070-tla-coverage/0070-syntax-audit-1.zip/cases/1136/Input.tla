---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
CONSTANT N
---- MODULE Inner ----
Init == x=0
Next == x'=IF x<N THEN x+1 ELSE 0
====
I == INSTANCE Inner
Init == x = 0
Next == I!Next
Safe == x \in 0..N
====