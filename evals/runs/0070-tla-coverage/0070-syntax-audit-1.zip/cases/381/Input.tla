---- MODULE Test ----
¬ value == value
====