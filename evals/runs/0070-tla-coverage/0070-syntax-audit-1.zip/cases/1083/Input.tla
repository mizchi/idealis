---- MODULE Test ----
Op == F( // )
====