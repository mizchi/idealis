---- MODULE Test ----
Op == F( \ )
====