---- MODULE Test ----
CONSTANT <> _
====