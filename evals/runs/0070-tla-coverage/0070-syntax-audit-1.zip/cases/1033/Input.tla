---- MODULE Test ----
left \ right == value
====