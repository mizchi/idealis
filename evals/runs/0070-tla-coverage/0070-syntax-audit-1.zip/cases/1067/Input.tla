---- MODULE Test ----
Op == F( ## )
====