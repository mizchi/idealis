---- MODULE Test ----
Op == F( ^# )
====