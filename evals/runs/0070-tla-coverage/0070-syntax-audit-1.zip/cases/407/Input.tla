---- MODULE Test ----
Op == F( /\ )
====