---- MODULE Test ----
Op == F( \neg )
====