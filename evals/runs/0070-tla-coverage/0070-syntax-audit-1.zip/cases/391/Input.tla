---- MODULE Test ----
Op == F( □ )
====