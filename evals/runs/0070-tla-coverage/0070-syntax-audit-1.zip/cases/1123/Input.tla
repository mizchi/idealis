---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
RECURSIVE Even(_), Odd(_)
Even(value) == IF value=0 THEN TRUE ELSE Odd(value-1)
Odd(value) == IF value=0 THEN FALSE ELSE Even(value-1)
Init == x = 3
Next == x'=IF Even(6) THEN 6 ELSE 7
Safe == x=3 \/ x=6
====