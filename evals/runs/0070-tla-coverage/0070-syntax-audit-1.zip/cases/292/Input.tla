
---- MODULE Test ----
op ≜
 ∧ 1
 / 2
 ∧ 3
====

