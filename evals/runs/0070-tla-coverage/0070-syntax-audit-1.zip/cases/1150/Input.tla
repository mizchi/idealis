---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Apply(F(_),value) == F(value)
Unused == Apply(LAMBDA TRUE: TRUE,1)
Init == x = 0
Next == UNCHANGED x
Safe == TRUE
====