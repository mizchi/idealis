---- MODULE Test ----
Op == F(\X)
====