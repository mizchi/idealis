
---- MODULE Test ----
THEOREM x == TRUE
PROOF OMITTED
====

