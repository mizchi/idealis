---- MODULE Test ----
Op == F( % )
====