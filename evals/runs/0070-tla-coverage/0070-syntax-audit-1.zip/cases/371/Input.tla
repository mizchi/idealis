---- MODULE Test ----
Op == F( \lnot )
====