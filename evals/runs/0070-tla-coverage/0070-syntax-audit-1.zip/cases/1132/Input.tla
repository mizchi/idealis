---- MODULE Completion ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x

Init == x = SelectSeq(<<1,2,3>>,LAMBDA value: value>1)
Next == UNCHANGED x
Safe == x = <<2,3>>
====