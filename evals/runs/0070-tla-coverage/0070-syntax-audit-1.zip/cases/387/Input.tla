---- MODULE Test ----
Op == F( [] )
====