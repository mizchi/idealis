---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Factorial[value \in 0..5] == IF value=0 THEN 1 ELSE value*Factorial[value-1]
Init == x = Factorial[5]
Next == UNCHANGED x
Safe == x=120
====