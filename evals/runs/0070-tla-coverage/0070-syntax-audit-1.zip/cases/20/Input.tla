
---- MODULE Test ----
ASSUME a1 == TRUE
ASSUMPTION a2 == TRUE
AXIOM a3 == TRUE
====

