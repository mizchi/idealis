---- MODULE Test ----
CONSTANT □ _
====