---- MODULE Test ----
value ^* == value
====