---- MODULE Test ----
CONSTANT [] _
====