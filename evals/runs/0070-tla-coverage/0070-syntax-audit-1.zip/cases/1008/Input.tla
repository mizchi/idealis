---- MODULE Test ----
Op == UNION value
====