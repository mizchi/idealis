---- MODULE Test ----
Op == F( @@ )
====