---- MODULE Test ----
value ^# == value
====