---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Op == CASE TRUE -> 3 [] OTHER -> 4
Init == x = Op!1!2
Next == UNCHANGED x
Safe == x=3
====