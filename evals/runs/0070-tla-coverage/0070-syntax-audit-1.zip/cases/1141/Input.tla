---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
I(increment) == INSTANCE Parameter WITH N <- increment
Combine(F(_,_), left, right) == F(left,right)
Init == x = 0
Next == x'=Combine(I!Add,1,x)%3
Safe == x \in 0..2
====