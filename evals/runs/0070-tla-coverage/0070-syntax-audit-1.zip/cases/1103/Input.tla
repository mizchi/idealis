---- MODULE Test ----
Op == ASSUME TRUE PROVE TRUE
====