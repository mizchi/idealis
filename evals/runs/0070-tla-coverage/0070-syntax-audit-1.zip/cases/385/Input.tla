---- MODULE Test ----
[] value == value
====