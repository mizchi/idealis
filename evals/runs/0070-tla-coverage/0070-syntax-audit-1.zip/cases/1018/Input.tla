---- MODULE Test ----
CONSTANT _ ^*
====