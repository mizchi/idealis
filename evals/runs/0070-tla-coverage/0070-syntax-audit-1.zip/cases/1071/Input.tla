---- MODULE Test ----
Op == F( ++ )
====