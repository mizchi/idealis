---- MODULE Test ----
UNION value == value
====