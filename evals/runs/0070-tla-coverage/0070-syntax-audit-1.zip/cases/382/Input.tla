---- MODULE Test ----
CONSTANT ¬ _
====