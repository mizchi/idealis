---- MODULE Test ----
\neg value == value
====