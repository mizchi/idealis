---- MODULE Test ----
Op == LAMBDA value: value
====