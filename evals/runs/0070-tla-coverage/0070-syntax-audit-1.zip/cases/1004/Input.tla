---- MODULE Test ----
Op == SUBSET value
====