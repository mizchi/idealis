---- MODULE Test ----
□ value == value
====