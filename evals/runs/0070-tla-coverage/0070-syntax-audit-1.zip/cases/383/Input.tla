---- MODULE Test ----
Op == F( ¬ )
====