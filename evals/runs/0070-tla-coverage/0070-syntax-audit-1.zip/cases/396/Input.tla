---- MODULE Test ----
Op == ◇ value
====