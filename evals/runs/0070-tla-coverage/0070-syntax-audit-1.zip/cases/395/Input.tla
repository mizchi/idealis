---- MODULE Test ----
Op == F( <> )
====