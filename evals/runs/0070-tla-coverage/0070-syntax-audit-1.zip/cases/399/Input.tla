---- MODULE Test ----
Op == F( ◇ )
====