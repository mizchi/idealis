---- MODULE Test ----
Op == F( $ )
====