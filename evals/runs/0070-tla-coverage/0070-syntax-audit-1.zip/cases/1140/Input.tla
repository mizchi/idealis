---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
I(increment) == INSTANCE Parameter WITH N <- increment
Apply(F(_), value) == F(value)
Init == x = 0
Next == x'=Apply(I(1)!Add,x)%3
Safe == x \in 0..2
====