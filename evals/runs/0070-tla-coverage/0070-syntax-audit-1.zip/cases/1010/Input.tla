---- MODULE Test ----
CONSTANT UNION _
====