---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Op == 1+2
Init == x = Op!2
Next == UNCHANGED x
Safe == x=2
====