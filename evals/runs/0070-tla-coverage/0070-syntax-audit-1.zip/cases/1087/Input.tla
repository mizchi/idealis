---- MODULE Test ----
Op == F( ^^ )
====