---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Unused == [<<1>> EXCEPT ![1]=label::@]
Init == x = 0
Next == UNCHANGED x
Safe == TRUE
====