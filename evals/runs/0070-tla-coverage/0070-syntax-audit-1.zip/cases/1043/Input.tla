---- MODULE Test ----
Op == F( && )
====