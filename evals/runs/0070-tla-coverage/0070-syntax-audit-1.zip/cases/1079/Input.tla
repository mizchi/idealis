---- MODULE Test ----
Op == F( ** )
====