---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Apply(F(_), value) == F(value)
Init == x = 0
Next == \E delta \in 1..2: x'=Apply(LAMBDA value: (value+delta)%3,x)
Safe == x \in 0..2
====