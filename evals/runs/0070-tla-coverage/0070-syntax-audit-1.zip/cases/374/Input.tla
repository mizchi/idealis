---- MODULE Test ----
CONSTANT ~ _
====