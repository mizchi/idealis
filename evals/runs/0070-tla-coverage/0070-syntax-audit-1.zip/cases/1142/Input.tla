---- MODULE Completion ----
CONSTANT N
VARIABLE x
---- MODULE Inner ----
Value == N
====
I == INSTANCE Inner WITH N <- 1
Init == x=I!Value
Next == UNCHANGED x
Safe == TRUE
====