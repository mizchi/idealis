
---- MODULE Test ----
op == [
  foo |->
    /\ 1
    /\ 2,
      bar |->
        \/ 3
        \/ 4
]
====

