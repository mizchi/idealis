---- MODULE Test ----
Op == left \land right
====