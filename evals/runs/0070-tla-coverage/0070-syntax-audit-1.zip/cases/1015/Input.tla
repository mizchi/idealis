---- MODULE Test ----
Op == F( DOMAIN )
====