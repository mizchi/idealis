---- MODULE Test ----
CONSTANT _ ^#
====