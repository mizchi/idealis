---- MODULE Test ----
Op == F( <: )
====