
---- MODULE Test ----
op == <<>> 
====

