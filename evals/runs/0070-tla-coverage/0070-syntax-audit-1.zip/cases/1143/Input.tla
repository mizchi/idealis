---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Apply(F(_),value) == F(value)
Init == x = 0
Next == UNCHANGED x
Safe == \A left,right \in {1,2}: LET Add(value) == left+right+value IN Add(0)=left+right
====