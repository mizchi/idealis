---- MODULE Test ----
Op == <> value
====