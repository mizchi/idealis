---- MODULE Test ----
SUBSET value == value
====