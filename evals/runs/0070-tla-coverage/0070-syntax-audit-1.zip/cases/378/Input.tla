---- MODULE Test ----
CONSTANT \neg _
====