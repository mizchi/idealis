---- MODULE Test ----
Op == F( ~ )
====