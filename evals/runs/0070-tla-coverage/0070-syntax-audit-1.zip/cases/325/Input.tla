
---- MODULE Test ----
op ==
    ∧ 1
    ∧ f[
        ∨ 2
        ∨ 3,
        ∧ 4
          ]
====

