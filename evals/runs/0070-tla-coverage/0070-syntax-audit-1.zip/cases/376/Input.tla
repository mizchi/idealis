---- MODULE Test ----
Op == \neg value
====