---- MODULE Test ----
Op == left :> right
====