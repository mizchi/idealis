---- MODULE Test ----
Op == F( UNION )
====