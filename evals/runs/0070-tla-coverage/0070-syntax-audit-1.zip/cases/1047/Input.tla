---- MODULE Test ----
Op == F( & )
====