---- MODULE Test ----
Op == F( > )
====