
---- MODULE Test ----
op == f(
  ^+,
  ^*,
  ^#,
  '
)
====

