---- MODULE Test ----
Op == F( :> )
====