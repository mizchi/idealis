---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Unused[bound \in {1}] == label(bound)::bound
Init == x = 0
Next == UNCHANGED x
Safe == TRUE
====