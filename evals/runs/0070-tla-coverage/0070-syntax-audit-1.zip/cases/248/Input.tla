
---- MODULE Test ----
op == "\*"
====

