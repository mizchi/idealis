---- MODULE Completion ----
EXTENDS Naturals
VARIABLE x
Op == LET Inner(value) == value+1 IN TRUE
Init == x = Op!:!Inner(2)
Next == UNCHANGED x
Safe == x=3
====