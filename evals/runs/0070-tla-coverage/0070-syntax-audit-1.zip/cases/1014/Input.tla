---- MODULE Test ----
CONSTANT DOMAIN _
====