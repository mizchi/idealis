
---- MODULE Test ----
COROLLARY def == TRUE
PROOF OBVIOUS
====

