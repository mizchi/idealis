---- MODULE Test ----
Op == □ value
====