---- MODULE Test ----
Op == F( | )
====