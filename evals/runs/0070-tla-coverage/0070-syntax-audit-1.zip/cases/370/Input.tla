---- MODULE Test ----
CONSTANT \lnot _
====