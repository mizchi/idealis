---- MODULE Test ----
Op == F( $$ )
====