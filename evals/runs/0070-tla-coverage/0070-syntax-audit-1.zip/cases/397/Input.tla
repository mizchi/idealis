---- MODULE Test ----
◇ value == value
====