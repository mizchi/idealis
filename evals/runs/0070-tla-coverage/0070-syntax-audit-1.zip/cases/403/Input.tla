---- MODULE Test ----
Op == F( \land )
====