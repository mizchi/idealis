---- MODULE Test ----
Op == UNCHANGED value
====