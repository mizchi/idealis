---- MODULE Test ----
Op == F( < )
====