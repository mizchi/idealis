---- MODULE SharingControl ----
VARIABLE x
Init == x = 0
Next == UNCHANGED x
Safe == x = 0 /\ [<<{9}>> EXCEPT ![1] = LET f[i \in @] == i IN ENABLED (x' = f[9])][1]
====