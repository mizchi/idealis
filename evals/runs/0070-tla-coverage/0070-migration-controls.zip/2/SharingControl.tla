---- MODULE SharingControl ----
VARIABLE x
Init == x = 0
Next == UNCHANGED x
Safe == x = 0 /\ [<<{9}>> EXCEPT ![1] = LET Id(a) == LET f[i \in @] == i IN f[9] IN Id(0) = 9][1]
====