---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Unused == IF TRUE THEN label::1 ELSE label::2
Init == x = 0
Next == UNCHANGED x
Safe == TRUE
====