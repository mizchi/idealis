---- MODULE Differential ----
EXTENDS Naturals, Sequences
VARIABLE x

Init == x = 0
Next == UNCHANGED x
Safe == x=0 /\ [<<9>> EXCEPT ![1] = LET Step == @=9 /\ x'=x IN [<<4>> EXCEPT ![1] = ENABLED Step][1]][1]
====