---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Apply(F(_), value) == F(value)
Inc(value) == (value+1)%3
Init == x = 0
Next == x'=Apply(Inc,x)
Safe == x \in 0..2
====