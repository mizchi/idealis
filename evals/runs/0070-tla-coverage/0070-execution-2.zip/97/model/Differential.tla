---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
C(limit) == INSTANCE Counter WITH Limit <- limit, value <- x
Init == C(2)!Init
Next == C(2)!Next
Safe == x # x
====