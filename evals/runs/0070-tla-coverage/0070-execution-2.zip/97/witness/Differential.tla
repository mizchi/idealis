---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
C(limit) == INSTANCE Counter WITH Limit <- limit, value <- x
Init == C(2)!Init
Next == C(2)!Next
Safe == x # x

VARIABLE __position
__TraceInit == Init /\ __position = 0 /\ (x = 0)
__TraceNext == ((__position = 0 /\ __position' = 0 /\ (x' = 0))) /\ (Next \/ UNCHANGED <<x>>)
__TraceSpec == __TraceInit /\ [][__TraceNext]_<<x,__position>> /\ WF_<<x,__position>>(__TraceNext)
__Expected == <>(~(Safe))
====