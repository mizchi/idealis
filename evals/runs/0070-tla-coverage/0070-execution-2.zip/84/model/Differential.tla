---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x

Init == x = 0
Next == UNCHANGED x
Safe == x=0 /\ [<<{9}>> EXCEPT ![1] = LET Pick == CHOOSE value \in {}: @=value IN TRUE][1]
====