---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Apply(F(_),value) == F(value)
Init == x = 0
Next == UNCHANGED x
Safe == \A left,right \in {1,2}: Apply(LAMBDA value: left+right+value,0)=left+right
====