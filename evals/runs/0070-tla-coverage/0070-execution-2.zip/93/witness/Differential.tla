---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Op == 1+2
Init == x = Op!2
Next == UNCHANGED x
Safe == x # x

VARIABLE __position
__TraceInit == Init /\ __position = 0 /\ (x = 2)
__TraceNext == ((__position = 0 /\ __position' = 0 /\ (x' = 2))) /\ (Next \/ UNCHANGED <<x>>)
__TraceSpec == __TraceInit /\ [][__TraceNext]_<<x,__position>> /\ WF_<<x,__position>>(__TraceNext)
__Expected == <>(~(Safe))
====