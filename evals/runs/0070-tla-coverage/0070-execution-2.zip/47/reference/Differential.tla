---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
CONSTANT N
---- MODULE Inner ----
CONSTANT N
Value == N
====
I == INSTANCE Inner WITH N <- 1
Init == x = I!Value
Next == UNCHANGED x
Safe == x=1
====