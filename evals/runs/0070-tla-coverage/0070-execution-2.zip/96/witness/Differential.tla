---- MODULE Differential ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x
Apply(F(_), value) == F(value)
Update(value) == [<<1>> EXCEPT ![1]=@+value]
Init == x = [<<2>> EXCEPT ![1]=Apply(Update,@)[1]]
Next == UNCHANGED x
Safe == x # x

VARIABLE __position
__TraceInit == Init /\ __position = 0 /\ (x = <<3>>)
__TraceNext == ((__position = 0 /\ __position' = 0 /\ (x' = <<3>>))) /\ (Next \/ UNCHANGED <<x>>)
__TraceSpec == __TraceInit /\ [][__TraceNext]_<<x,__position>> /\ WF_<<x,__position>>(__TraceNext)
__Expected == <>(~(Safe))
====