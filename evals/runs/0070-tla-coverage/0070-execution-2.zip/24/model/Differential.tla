---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Op == [first |-> 1, second |-> 3]
Init == x = Op!2
Next == UNCHANGED x
Safe == x=3
====