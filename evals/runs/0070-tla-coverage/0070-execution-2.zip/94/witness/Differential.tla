---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
RECURSIVE Fact(_)
Fact(value) == IF value=0 THEN 1 ELSE value*Fact(value-1)
Init == x = 3
Next == x'=Fact(5)
Safe == x # x

VARIABLE __position
__TraceInit == Init /\ __position = 0 /\ (x = 3)
__TraceNext == ((__position = 0 /\ __position' = 0 /\ (x' = 3))) /\ (Next \/ UNCHANGED <<x>>)
__TraceSpec == __TraceInit /\ [][__TraceNext]_<<x,__position>> /\ WF_<<x,__position>>(__TraceNext)
__Expected == <>(~(Safe))
====