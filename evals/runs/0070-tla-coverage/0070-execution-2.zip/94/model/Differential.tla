---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
RECURSIVE Fact(_)
Fact(value) == IF value=0 THEN 1 ELSE value*Fact(value-1)
Init == x = 3
Next == x'=Fact(5)
Safe == x # x
====