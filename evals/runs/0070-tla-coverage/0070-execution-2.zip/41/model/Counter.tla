---- MODULE Counter ----
EXTENDS Naturals
CONSTANT Limit
VARIABLE value
Init == value=0
Next == value'=IF value<Limit THEN value+1 ELSE 0
Safe == value \in 0..Limit
====