---- MODULE Differential ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x

Init == x = SortSeq(<<3,1,2>>,LAMBDA left,right: left<=right)
Next == UNCHANGED x
Safe == x = <<1,2,3>>
====