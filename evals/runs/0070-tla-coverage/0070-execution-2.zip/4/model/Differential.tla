---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Apply(F(_), value) == F(value)
Forward(G(_), value) == Apply(G,value)
Init == x = 0
Next == x'=Forward(LAMBDA value: (value+1)%3,x)
Safe == x \in 0..2
====