---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Run(A(_), value) == A(value)
Assign(value) == x'=value
Init == x = 0
Next == Run(Assign,(x+1)%3)
Safe == x \in 0..2
====