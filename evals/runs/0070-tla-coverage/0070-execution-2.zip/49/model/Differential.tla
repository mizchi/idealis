---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Base == 2
---- MODULE Inner ----
Value == Base
====
I == INSTANCE Inner
Init == x = I!Value
Next == UNCHANGED x
Safe == x=2
====