---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Unused == \A outer \in {1}: first(outer):: \A inner \in {2}: second(inner)::TRUE
Init == x = 0
Next == UNCHANGED x
Safe == x # x
====