---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Op(value) == \A bound \in 0..2: label(bound)::value+bound
Init == x = Op(1)!label(2)
Next == UNCHANGED x
Safe == x=3
====