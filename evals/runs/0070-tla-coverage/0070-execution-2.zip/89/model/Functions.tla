---- MODULE Functions ----
EXTENDS Naturals
CONSTANT Limit
Factorial[value \in 0..Limit] == IF value=0 THEN 1 ELSE value*Factorial[value-1]
====