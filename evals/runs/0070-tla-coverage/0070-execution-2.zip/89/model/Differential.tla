---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
I(limit) == INSTANCE Functions WITH Limit <- limit
Init == x = I(5)!Factorial[5]
Next == UNCHANGED x
Safe == x=120
====