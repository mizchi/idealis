---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Fn[left \in 0..2, right \in 0..2] == IF left=0 THEN right ELSE Fn[left-1,right]+1
Init == x = Fn[2,1]
Next == UNCHANGED x
Safe == x=3
====