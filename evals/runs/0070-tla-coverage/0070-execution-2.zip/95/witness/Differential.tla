---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Factorial[value \in 0..5] == IF value=0 THEN 1 ELSE value*Factorial[value-1]
Init == x = Factorial[5]
Next == UNCHANGED x
Safe == x # x

VARIABLE __position
__TraceInit == Init /\ __position = 0 /\ (x = 120)
__TraceNext == ((__position = 0 /\ __position' = 0 /\ (x' = 120))) /\ (Next \/ UNCHANGED <<x>>)
__TraceSpec == __TraceInit /\ [][__TraceNext]_<<x,__position>> /\ WF_<<x,__position>>(__TraceNext)
__Expected == <>(~(Safe))
====