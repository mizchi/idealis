---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x

Init == x = 0
Next == UNCHANGED x
Safe == x=0 /\ [<<{9}>> EXCEPT ![1] = LET Pick == CHOOSE value \in @: TRUE IN Pick=9][1]
====