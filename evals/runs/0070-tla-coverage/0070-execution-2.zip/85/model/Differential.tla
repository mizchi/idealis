---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x

Init == x = 0
Next == UNCHANGED x
Safe == x=0 /\ [<<{9}>> EXCEPT ![1] = LET Fn[value \in @] == value IN Fn[9]=9][1]
====