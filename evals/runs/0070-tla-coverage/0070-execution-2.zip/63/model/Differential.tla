---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
RECURSIVE Even(_)
Even(value) == IF value=0 THEN TRUE ELSE IF value=1 THEN FALSE ELSE Even(value-2)
Init == x = 0
Next == Even(2*x) /\ x'=(x+1)%3
Safe == []Even(2*x)
====