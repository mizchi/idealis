---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Unused == \A bound \in {1}: label(other)::TRUE
Init == x = 0
Next == UNCHANGED x
Safe == TRUE
====