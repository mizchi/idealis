---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
RECURSIVE Unused(_,_)
Unused(value) == value
Init == x = 0
Next == UNCHANGED x
Safe == TRUE
====