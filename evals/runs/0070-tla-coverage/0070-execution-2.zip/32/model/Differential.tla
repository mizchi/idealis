---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Fn[value \in 0..1] == IF value=0 THEN 0 ELSE Fn[1]
Init == x = DOMAIN Fn
Next == UNCHANGED x
Safe == x=0..1
====