---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Combine(F(_,_), left, right) == F(left,right)
Init == x = 0
Next == x'=Combine(+,x,1)%3
Safe == x \in 0..2
====