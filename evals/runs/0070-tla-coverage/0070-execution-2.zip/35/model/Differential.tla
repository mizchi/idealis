---- MODULE Differential ----
EXTENDS Naturals, Sequences, TLC
VARIABLE x
Filter(P(_), seq) == SelectSeq(seq,P)
Init == x = Filter(LAMBDA value: value>1,<<1,2,3>>)
Next == UNCHANGED x
Safe == x = <<2,3>>
====