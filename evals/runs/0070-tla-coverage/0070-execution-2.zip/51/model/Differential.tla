---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
CONSTANT N
---- MODULE First ----
Value == N
====
---- MODULE Second ----
EXTENDS First
Result == Value
====
I == INSTANCE Second
Init == x = I!Result
Next == UNCHANGED x
Safe == x=2
====