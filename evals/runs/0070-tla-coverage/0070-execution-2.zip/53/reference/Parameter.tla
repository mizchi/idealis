---- MODULE Parameter ----
EXTENDS Naturals
CONSTANT N
Add(value) == value+N
====