---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Apply(F(_),value) == F(value)
Unused == \A outer \in {1}: Apply(LAMBDA inner: label(outer,inner)::TRUE,2)
Init == x = 0
Next == UNCHANGED x
Safe == TRUE
====