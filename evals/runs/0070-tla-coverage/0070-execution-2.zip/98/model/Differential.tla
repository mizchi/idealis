---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Apply(F(_),value) == F(value)
Init == x = 0
Next == UNCHANGED x
Safe == x # x
====