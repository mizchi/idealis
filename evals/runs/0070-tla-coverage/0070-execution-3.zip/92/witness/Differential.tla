---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Run(A(_),value) == A(value)
Assign(value) == x'=value
Init == x = 0
Next == Run(Assign,(x+1)%3)
Safe == x=0

VARIABLE __position
__TraceInit == Init /\ __position = 0 /\ (x = 0)
__TraceNext == ((__position = 0 /\ __position' = 1 /\ (x' = 1)) \/ (__position = 1 /\ __position' = 1 /\ (x' = 1))) /\ (Next \/ UNCHANGED <<x>>)
__TraceSpec == __TraceInit /\ [][__TraceNext]_<<x,__position>> /\ WF_<<x,__position>>(__TraceNext)
__Expected == <>(~(Safe))
====