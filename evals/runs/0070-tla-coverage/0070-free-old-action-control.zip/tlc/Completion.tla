---- MODULE Completion ----
EXTENDS Naturals, Sequences
VARIABLE x
Init == x=0
Next == UNCHANGED x
Safe == x=0 /\ [<<9>> EXCEPT ![1] = LET Step(a) == @=9 /\ x'=a IN [<<4>> EXCEPT ![1] = ENABLED Step(x)][1]][1]
====