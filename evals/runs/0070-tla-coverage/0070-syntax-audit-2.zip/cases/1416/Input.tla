---- MODULE Test ----
Op == ∀ n: TRUE
====