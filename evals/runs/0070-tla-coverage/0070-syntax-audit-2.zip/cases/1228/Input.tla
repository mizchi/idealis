---- MODULE Test ----
Op == 1 \prec 1
====