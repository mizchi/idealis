---- MODULE Test ----
Op == 1 \propto 1
====