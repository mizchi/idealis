---- MODULE Test ----
I == INSTANCE Symbols WITH ~ <- ~
INSTANCE Other
====