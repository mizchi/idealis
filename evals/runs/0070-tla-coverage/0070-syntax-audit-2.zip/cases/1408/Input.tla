---- MODULE Test ----
Op == {1} \times {2}
====