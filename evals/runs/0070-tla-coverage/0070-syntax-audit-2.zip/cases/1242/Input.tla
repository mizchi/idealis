---- MODULE Test ----
Op == 1 \sqsubset 1
====