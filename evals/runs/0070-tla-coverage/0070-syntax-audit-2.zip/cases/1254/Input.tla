---- MODULE Test ----
Op == 1 \succ 1
====