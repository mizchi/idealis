---- MODULE Test ----
Op == 1 \sqsubseteq 1
====