---- MODULE Test ----
Op == 1 \subset 1
====