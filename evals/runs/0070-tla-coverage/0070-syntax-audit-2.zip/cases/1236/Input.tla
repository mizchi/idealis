---- MODULE Test ----
Op == 1 \simeq 1
====