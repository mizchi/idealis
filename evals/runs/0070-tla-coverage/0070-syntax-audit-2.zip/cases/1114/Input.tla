---- MODULE Test ----
I == INSTANCE Symbols WITH ~ <- ~
CONSTANT value
====