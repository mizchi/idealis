---- MODULE Test ----
I == INSTANCE Symbols WITH F <- \X
====