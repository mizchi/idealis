---- MODULE Probe ----
EXTENDS Naturals, Integers, Sequences, FiniteSets, Apalache
VARIABLE x
Init == x = 0
Next == UNCHANGED x
Probe == 1 \supseteq 1
====