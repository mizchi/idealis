---- MODULE Test ----
Op == 1 \otimes 1
====