---- MODULE Test ----
Op == 1 \bigcirc 1
====