---- MODULE Test ----
Op == 1 \uplus 1
====