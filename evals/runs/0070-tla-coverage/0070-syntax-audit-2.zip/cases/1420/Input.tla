---- MODULE Test ----
Op == \exists n: TRUE
====