---- MODULE Test ----
I == INSTANCE Symbols WITH ~ <- ~
Next(value) == value
====