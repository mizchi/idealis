---- MODULE Test ----
Op == >=(1,2)
====