---- MODULE Test ----
Op == 1 \sqsupseteq 1
====