---- MODULE Test ----
I == INSTANCE Symbols WITH ~ <- ~
RECURSIVE F(_)
F(value) == value
====