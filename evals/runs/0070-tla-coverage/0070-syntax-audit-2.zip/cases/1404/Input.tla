---- MODULE Test ----
Op == [1]
====