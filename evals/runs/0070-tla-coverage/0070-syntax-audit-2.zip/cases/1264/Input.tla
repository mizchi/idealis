---- MODULE Test ----
Op == 1 \wr 1
====