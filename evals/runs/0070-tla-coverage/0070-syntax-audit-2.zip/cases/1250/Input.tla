---- MODULE Test ----
Op == 1 \star 1
====