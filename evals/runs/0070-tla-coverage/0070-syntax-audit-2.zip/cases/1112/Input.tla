---- MODULE Test ----
I == INSTANCE Symbols WITH ~ <- ~
ASSUME TRUE
====