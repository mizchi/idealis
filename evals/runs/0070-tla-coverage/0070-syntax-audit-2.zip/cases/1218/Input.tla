---- MODULE Test ----
Op == 1 \odot 1
====