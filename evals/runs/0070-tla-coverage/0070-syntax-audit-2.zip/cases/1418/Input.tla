---- MODULE Test ----
Op == \E n: TRUE
====