---- MODULE Test ----
Op == 1 \cong 1
====