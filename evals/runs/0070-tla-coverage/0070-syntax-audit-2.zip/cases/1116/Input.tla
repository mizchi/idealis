---- MODULE Test ----
I == INSTANCE Symbols WITH ~ <- ~
LOCAL Next == TRUE
====