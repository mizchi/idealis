---- MODULE Test ----
I == INSTANCE Symbols WITH ~ <- ~
left %% right == left
====