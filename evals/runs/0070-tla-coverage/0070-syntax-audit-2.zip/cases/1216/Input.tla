---- MODULE Test ----
Op == 1 \ll 1
====