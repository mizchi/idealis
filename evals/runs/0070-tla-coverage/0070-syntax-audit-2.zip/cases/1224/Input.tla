---- MODULE Test ----
Op == 1 \oslash 1
====