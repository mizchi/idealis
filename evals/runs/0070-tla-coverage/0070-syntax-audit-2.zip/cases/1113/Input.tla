---- MODULE Test ----
I == INSTANCE Symbols WITH ~ <- ~
THEOREM TRUE
====