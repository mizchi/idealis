---- MODULE Test ----
Op == 1 \oplus 1
====