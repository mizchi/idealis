---- MODULE Test ----
Op == 1 \succeq 1
====