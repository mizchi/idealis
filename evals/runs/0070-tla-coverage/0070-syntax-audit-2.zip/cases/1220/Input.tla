---- MODULE Test ----
Op == 1 \ominus 1
====