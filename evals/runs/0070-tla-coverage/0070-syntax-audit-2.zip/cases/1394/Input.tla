---- MODULE Test ----
Op == 1 \cdot 1
====