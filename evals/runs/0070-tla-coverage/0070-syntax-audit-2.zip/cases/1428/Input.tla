---- MODULE Test ----
Op == CHOOSE n: TRUE
====