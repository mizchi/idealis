---- MODULE Test ----
Op == 1 \sqcap 1
====