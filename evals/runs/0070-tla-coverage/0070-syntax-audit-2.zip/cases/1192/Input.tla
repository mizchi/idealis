---- MODULE Test ----
Op == 1 (\X) 1
====