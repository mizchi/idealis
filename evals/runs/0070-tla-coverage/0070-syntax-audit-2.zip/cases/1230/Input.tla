---- MODULE Test ----
Op == 1 \preceq 1
====