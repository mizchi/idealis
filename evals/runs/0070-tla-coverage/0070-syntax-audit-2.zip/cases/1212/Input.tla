---- MODULE Test ----
Op == 1 \doteq 1
====