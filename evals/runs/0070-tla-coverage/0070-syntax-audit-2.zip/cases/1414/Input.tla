---- MODULE Test ----
Op == \forall n: TRUE
====