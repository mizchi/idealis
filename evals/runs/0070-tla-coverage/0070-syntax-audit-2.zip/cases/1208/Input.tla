---- MODULE Test ----
Op == 1 \bullet 1
====