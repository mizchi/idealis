---- MODULE Test ----
Op == 1 \sqcup 1
====