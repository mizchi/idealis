---- MODULE Test ----
Op == 1 \supset 1
====