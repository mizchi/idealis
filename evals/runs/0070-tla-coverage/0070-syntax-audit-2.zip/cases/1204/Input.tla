---- MODULE Test ----
Op == 1 \asymp 1
====