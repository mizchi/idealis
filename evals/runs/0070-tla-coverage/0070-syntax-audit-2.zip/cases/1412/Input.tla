---- MODULE Test ----
Op == \A n: TRUE
====