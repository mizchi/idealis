---- MODULE Test ----
Op == 1 \sqsupset 1
====