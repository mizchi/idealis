---- MODULE Completion ----
EXTENDS Naturals, Sequences
VARIABLE x
ASSUME SelectSeq(<<1,2>>,LAMBDA value: value>1)=<<2>>
Init == x = 0
Next == UNCHANGED x
Safe == x=0
====