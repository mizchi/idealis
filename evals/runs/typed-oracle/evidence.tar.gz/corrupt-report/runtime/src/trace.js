export class TraceFormatError extends Error {
    name = "TraceFormatError";
}
export const isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
export const valueKey = (value) => {
    const ancestors = new Set();
    const visit = (current) => {
        if (current === null ||
            typeof current === "string" ||
            typeof current === "boolean") {
            return JSON.stringify(current);
        }
        if (typeof current === "number" && Number.isFinite(current))
            return JSON.stringify(current);
        if (typeof current !== "object" ||
            current === null ||
            ancestors.has(current)) {
            throw new TraceFormatError("Expected acyclic JSON values; encode bigint, sets and maps explicitly");
        }
        ancestors.add(current);
        try {
            if (Array.isArray(current)) {
                return `[${Array.from(current, (item) => visit(item)).join(",")}]`;
            }
            if (Object.getPrototypeOf(current) !== Object.prototype &&
                Object.getPrototypeOf(current) !== null) {
                throw new TraceFormatError("Expected a plain JSON object");
            }
            return `{${Object.entries(current)
                .sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0))
                .map(([key, item]) => `${JSON.stringify(key)}:${visit(item)}`)
                .join(",")}}`;
        }
        finally {
            ancestors.delete(current);
        }
    };
    return visit(value);
};
export const equalValues = (expected, actual) => valueKey(expected) === valueKey(actual);
export const encodeTrace = (trace) => {
    valueKey(trace);
    return JSON.stringify(trace, null, 2);
};
export const decodeTrace = (text, guards) => {
    const value = JSON.parse(text);
    if (!isRecord(value) ||
        value.version !== 1 ||
        typeof value.model !== "string" ||
        !guards.observation(value.initial) ||
        !Array.isArray(value.steps)) {
        throw new TraceFormatError("Invalid trace header");
    }
    const steps = value.steps.map((step) => {
        if (!isRecord(step) ||
            !guards.action(step.action) ||
            !guards.observation(step.observation)) {
            throw new TraceFormatError("Invalid trace step");
        }
        return { action: step.action, observation: step.observation };
    });
    return { version: 1, model: value.model, initial: value.initial, steps };
};
