import { decodeOracleReply, } from "../workspace-oracle/protocol.js";
import { encodeBatch, encodeBuffer } from "./encode.js";
export const witClient = (root, mode) => ({
    request: (input) => {
        const batch = encodeBatch(input);
        return decodeOracleReply(mode === "wit-record"
            ? root.protocol.check(batch)
            : root.protocol.checkBuffer(encodeBuffer(batch)));
    },
});
