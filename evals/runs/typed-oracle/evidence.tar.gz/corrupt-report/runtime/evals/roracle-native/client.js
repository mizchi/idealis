import { createRequire } from "node:module";
import { resolve } from "node:path";
import { isRecord } from "../../src/trace.js";
import { decodeOracleReply, } from "../workspace-oracle/protocol.js";
import { canonicalObject } from "./canonical.js";
export const nativePath = "evals/roracle-native/generated/roracle-native.node";
export const loadNativeBinding = (path = nativePath) => {
    const input = createRequire(import.meta.url)(resolve(path));
    if (!isRecord(input) ||
        typeof input.abiVersion !== "function" ||
        input.abiVersion() !== 1 ||
        typeof input.dispatchJson !== "function" ||
        typeof input.dispatchObject !== "function")
        throw new Error("Invalid native oracle ABI");
    const nativeVersion = input.abiVersion;
    const nativeJson = input.dispatchJson;
    const nativeObject = input.dispatchObject;
    return {
        abiVersion: () => {
            const version = nativeVersion();
            if (typeof version !== "number")
                throw new Error("Invalid native ABI version");
            return version;
        },
        dispatchJson: (value) => {
            const result = nativeJson(value);
            if (typeof result !== "string")
                throw new Error("Invalid native JSON reply");
            return result;
        },
        dispatchObject: (value) => {
            const result = nativeObject(value);
            if (typeof result !== "string")
                throw new Error("Invalid native object reply");
            return result;
        },
    };
};
export const createNativeOracle = (mode, path = nativePath) => {
    const binding = loadNativeBinding(path);
    return {
        request: (input) => {
            if (mode === "native-object") {
                canonicalObject(input);
                return decodeOracleReply(binding.dispatchObject(input));
            }
            return decodeOracleReply(binding.dispatchJson(JSON.stringify(input)));
        },
    };
};
