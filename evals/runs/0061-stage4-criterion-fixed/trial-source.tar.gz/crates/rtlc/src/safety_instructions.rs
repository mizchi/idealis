use crate::CoreError;
use crate::ir::{Branch, Expression, Scalar, Step};
use crate::safety_expressions::EvalContext;
use crate::safety_values::Arena;

enum Instruction {
    Literal(Scalar),
    Read(usize, bool),
    Integer,
    Boolean,
    Not,
    Neg,
    Add,
    Sub,
    Mul,
    Lt,
    Le,
    Gt,
    Ge,
    Equal(bool),
    Branch(usize),
    Jump(usize),
}
struct Code(Vec<Instruction>);
impl Code {
    fn compile(expression: &Expression) -> Option<Self> {
        let mut code = Self(Vec::new());
        code.emit(expression, 0)?;
        Some(code)
    }
    fn conditional(
        &mut self,
        condition: &Expression,
        consequent: &Expression,
        alternative: &Expression,
        depth: usize,
    ) -> Option<()> {
        self.emit(condition, depth + 1)?;
        let branch = self.0.len();
        self.0.push(Instruction::Branch(0));
        self.emit(consequent, depth + 1)?;
        let jump = self.0.len();
        self.0.push(Instruction::Jump(0));
        self.0[branch] = Instruction::Branch(self.0.len());
        self.emit(alternative, depth + 1)?;
        self.0[jump] = Instruction::Jump(self.0.len());
        Some(())
    }
    fn emit(&mut self, expression: &Expression, depth: usize) -> Option<()> {
        if depth >= 32 {
            return None;
        }
        match expression {
            Expression::Literal { value } => self.0.push(Instruction::Literal(*value)),
            Expression::Read { slot, next } => self.0.push(Instruction::Read(*slot, *next)),
            Expression::Not { argument } | Expression::Neg { argument } => {
                self.emit(argument, depth + 1)?;
                self.0
                    .push(if matches!(expression, Expression::Not { .. }) {
                        Instruction::Not
                    } else {
                        Instruction::Neg
                    });
            }
            Expression::Add { left, right }
            | Expression::Sub { left, right }
            | Expression::Mul { left, right }
            | Expression::Lt { left, right }
            | Expression::Le { left, right }
            | Expression::Gt { left, right }
            | Expression::Ge { left, right } => {
                self.emit(left, depth + 1)?;
                self.0.push(Instruction::Integer);
                self.emit(right, depth + 1)?;
                self.0.push(Instruction::Integer);
                self.0.push(match expression {
                    Expression::Add { .. } => Instruction::Add,
                    Expression::Sub { .. } => Instruction::Sub,
                    Expression::Mul { .. } => Instruction::Mul,
                    Expression::Lt { .. } => Instruction::Lt,
                    Expression::Le { .. } => Instruction::Le,
                    Expression::Gt { .. } => Instruction::Gt,
                    _ => Instruction::Ge,
                });
            }
            Expression::Eq { left, right } | Expression::Ne { left, right } => {
                self.emit(left, depth + 1)?;
                self.emit(right, depth + 1)?;
                self.0.push(Instruction::Equal(matches!(
                    expression,
                    Expression::Eq { .. }
                )));
            }
            Expression::If {
                condition,
                consequent,
                alternative,
            } => self.conditional(condition, consequent, alternative, depth)?,
            Expression::And { left, right } => {
                self.conditional(
                    left,
                    right,
                    &Expression::Literal {
                        value: Scalar::Bool(false),
                    },
                    depth,
                )?;
                self.0.push(Instruction::Boolean);
            }
            Expression::Or { left, right } => {
                self.conditional(
                    left,
                    &Expression::Literal {
                        value: Scalar::Bool(true),
                    },
                    right,
                    depth,
                )?;
                self.0.push(Instruction::Boolean);
            }
            Expression::Implies { left, right } => {
                self.conditional(
                    left,
                    right,
                    &Expression::Literal {
                        value: Scalar::Bool(true),
                    },
                    depth,
                )?;
                self.0.push(Instruction::Boolean);
            }
            _ => return None,
        }
        Some(())
    }
    fn eval(&self, context: EvalContext<'_>, arena: &mut Arena) -> Result<Scalar, CoreError> {
        let mut stack = [Scalar::Int(0); 64];
        let mut height = 0;
        let mut index = 0;
        while let Some(instruction) = self.0.get(index) {
            match instruction {
                Instruction::Literal(value) => {
                    stack[height] = *value;
                    height += 1;
                }
                Instruction::Read(slot, next) => {
                    stack[height] = if *next || context.prime {
                        context.next.get(*slot).copied().flatten().ok_or_else(|| {
                            CoreError::protocol("Read of an unassigned next variable")
                        })?
                    } else {
                        context.current.get(*slot).copied().ok_or_else(|| {
                            CoreError::protocol("Read of a missing current variable")
                        })?
                    };
                    height += 1;
                }
                Instruction::Integer => {
                    stack[height - 1].integer()?;
                }
                Instruction::Boolean => {
                    stack[height - 1].boolean()?;
                }
                Instruction::Not => stack[height - 1] = Scalar::Bool(!stack[height - 1].boolean()?),
                Instruction::Neg => {
                    stack[height - 1] = Scalar::Int(
                        stack[height - 1]
                            .integer()?
                            .checked_neg()
                            .ok_or_else(|| CoreError::protocol("Safety integer overflow"))?,
                    )
                }
                Instruction::Branch(target) => {
                    height -= 1;
                    if !stack[height].boolean()? {
                        index = *target;
                        continue;
                    }
                }
                Instruction::Jump(target) => {
                    index = *target;
                    continue;
                }
                Instruction::Equal(expected) => {
                    height -= 1;
                    stack[height - 1] =
                        Scalar::Bool(arena.equal(stack[height - 1], stack[height])? == *expected);
                }
                _ => {
                    height -= 1;
                    let left = stack[height - 1].integer()?;
                    let right = stack[height].integer()?;
                    stack[height - 1] = match instruction {
                        Instruction::Lt => Scalar::Bool(left < right),
                        Instruction::Le => Scalar::Bool(left <= right),
                        Instruction::Gt => Scalar::Bool(left > right),
                        Instruction::Ge => Scalar::Bool(left >= right),
                        _ => Scalar::Int(
                            match instruction {
                                Instruction::Add => left.checked_add(right),
                                Instruction::Sub => left.checked_sub(right),
                                Instruction::Mul => left.checked_mul(right),
                                _ => unreachable!(),
                            }
                            .ok_or_else(|| CoreError::protocol("Safety integer overflow"))?,
                        ),
                    };
                }
            }
            index += 1;
        }
        Ok(stack[0])
    }
}
enum PlannedStep {
    Guard(Code),
    Assign(usize, Code),
}
pub(crate) struct BranchPlan(Vec<PlannedStep>);
impl BranchPlan {
    pub fn compile(branch: &Branch) -> Option<Self> {
        Some(Self(
            branch
                .steps
                .iter()
                .map(|step| match step {
                    Step::Guard { expression } => {
                        Some(PlannedStep::Guard(Code::compile(expression)?))
                    }
                    Step::Assign { slot, value } => {
                        Some(PlannedStep::Assign(*slot, Code::compile(value)?))
                    }
                    _ => None,
                })
                .collect::<Option<Vec<_>>>()?,
        ))
    }
    pub fn visit(
        &self,
        context: EvalContext<'_>,
        next: &mut [Option<Scalar>],
        arena: &mut Arena,
        visitor: &mut impl FnMut(&[Option<Scalar>], &mut Arena) -> Result<bool, CoreError>,
    ) -> Result<bool, CoreError> {
        let mut previous = Vec::with_capacity(next.len());
        let result = (|| {
            for step in &self.0 {
                arena.tick()?;
                let context = EvalContext { next, ..context };
                match step {
                    PlannedStep::Guard(code) => {
                        if !code.eval(context, arena)?.boolean()? {
                            return Ok(false);
                        }
                    }
                    PlannedStep::Assign(slot, code) => {
                        let value = code.eval(context, arena)?;
                        if let Some(previous) = next[*slot]
                            && !arena.equal(previous, value)?
                        {
                            return Ok(false);
                        }
                        previous.push((*slot, next[*slot]));
                        next[*slot] = Some(value);
                    }
                }
            }
            arena.tick()?;
            visitor(next, arena)
        })();
        for (slot, value) in previous.into_iter().rev() {
            next[slot] = value;
        }
        result
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    #[test]
    fn short_circuit_type_order_overflow_and_assignment_restoration_match() {
        for value in [
            json!({"op":"if","condition":{"op":"literal","value":{"type":"bool","value":false}},"consequent":{"op":"neg","argument":{"op":"literal","value":{"type":"int","value":"-2147483648"}}},"alternative":{"op":"literal","value":{"type":"int","value":"7"}}}),
            json!({"op":"add","left":{"op":"literal","value":{"type":"bool","value":false}},"right":{"op":"neg","argument":{"op":"literal","value":{"type":"int","value":"-2147483648"}}}}),
            json!({"op":"and","left":{"op":"literal","value":{"type":"bool","value":false}},"right":{"op":"literal","value":{"type":"int","value":"7"}}}),
        ] {
            let expression: Expression = serde_json::from_value(value).unwrap();
            let mut arena = Arena::new(100);
            let expected = expression
                .eval(EvalContext::new(&[], &[]), &mut arena)
                .map_err(|error| (error.code, error.message));
            let actual = Code::compile(&expression)
                .unwrap()
                .eval(EvalContext::new(&[], &[]), &mut arena)
                .map_err(|error| (error.code, error.message));
            assert_eq!(actual, expected);
        }
        let branch = Branch {
            name: "error".into(),
            steps: vec![
                Step::Assign {
                    slot: 0,
                    value: Expression::Literal {
                        value: Scalar::Int(1),
                    },
                },
                Step::Guard {
                    expression: Expression::Literal {
                        value: Scalar::Int(0),
                    },
                },
            ],
        };
        let mut next = [None];
        assert!(
            BranchPlan::compile(&branch)
                .unwrap()
                .visit(
                    EvalContext::new(&[], &[]),
                    &mut next,
                    &mut Arena::new(100),
                    &mut |_, _| Ok(false)
                )
                .is_err()
        );
        assert_eq!(next, [None]);
    }
}
