---- MODULE Test ----
Expr == a * outer :: inner :: b + c
====