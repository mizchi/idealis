---- MODULE Test ----
Expr == a + lab :: B \X C
====