---- MODULE Test ----
Expr == [] lab :: (x')
====