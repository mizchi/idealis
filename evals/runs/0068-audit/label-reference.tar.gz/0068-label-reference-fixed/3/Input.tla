---- MODULE Test ----
Expr == a * lab :: b
====