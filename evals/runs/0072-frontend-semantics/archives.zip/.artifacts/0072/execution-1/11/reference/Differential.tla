---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
RECURSIVE P(_)
P(a) == a'
Init == x=0
Next == x'=x
====