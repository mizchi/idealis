---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
P(a) == TRUE
Good == P([]TRUE)'
Init == x=0
Next == x'=x
====