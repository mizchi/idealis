---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
A0(v) == x'=v
A1(v) == A0(v) \/ A0(v)
A2(v) == A1(v) \/ A1(v)
A3(v) == A2(v) \/ A2(v)
T(limit) == []<>(x<limit)
Live == T(3) /\ T(3)
Init == x=0
Next == A3((x+1)%3)
Safe == x<3
====