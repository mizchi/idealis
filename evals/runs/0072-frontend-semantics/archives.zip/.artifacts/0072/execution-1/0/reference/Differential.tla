---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Bad == (x')'
Init == x=0
Next == x'=x
====