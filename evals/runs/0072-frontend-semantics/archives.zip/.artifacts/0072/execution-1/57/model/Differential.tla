---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
A0(v) == x'=v
A1(v) == A0(v) \/ A0(v)
T(limit) == []<>(x<limit)
Live == T(3) /\ T(3)
Init == x=0
Next == A1((x+1)%3)
Safe == x<2
====