---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
T(target) == []<>(x=target)
Both(target) == T(target) /\ T(target)
Init == x=0
Next == x'=(x+1)%3
Spec == Init /\ [][Next]_x /\ WF_x(Next)
Live == Both(4)
====