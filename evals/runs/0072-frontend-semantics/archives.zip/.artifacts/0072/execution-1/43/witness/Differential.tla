---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
T(target) == []<>(x=target)
Both(target) == T(target) /\ T(target)
Init == x=0
Next == x'=(x+1)%3
Spec == Init /\ [][Next]_x /\ WF_x(Next)
Live == Both(4)

VARIABLE __position
__TraceInit == Init /\ __position = 0 /\ (x = 0)
__TraceNext == ((__position = 0 /\ __position' = 1 /\ (x' = 1)) \/ (__position = 1 /\ __position' = 2 /\ (x' = 2)) \/ (__position = 2 /\ __position' = 3 /\ (x' = 0)) \/ (__position = 3 /\ __position' = 4 /\ (x' = 1)) \/ (__position = 4 /\ __position' = 5 /\ (x' = 2)) \/ (__position = 5 /\ __position' = 6 /\ (x' = 0)) \/ (__position = 6 /\ __position' = 7 /\ (x' = 1)) \/ (__position = 7 /\ __position' = 8 /\ (x' = 2)) \/ (__position = 8 /\ __position' = 9 /\ (x' = 0)) \/ (__position = 9 /\ __position' = 1 /\ (x' = 1))) /\ (Next \/ UNCHANGED <<x>>)
__TraceSpec == __TraceInit /\ [][__TraceNext]_<<x,__position>> /\ WF_<<x,__position>>(__TraceNext)
__Expected == (Spec) /\ ~(Live)
====