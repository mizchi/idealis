---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Bad == UNCHANGED (x')
Init == x=0
Next == x'=x
====