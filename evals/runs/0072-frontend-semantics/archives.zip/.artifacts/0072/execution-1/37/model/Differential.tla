---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Init == x=0
Next == \E delta \in {1,2}: LET Step(v) == x'=(x+delta+v)%4 IN Step(0) \/ Step(0) \/ Step(0) \/ Step(0)
====