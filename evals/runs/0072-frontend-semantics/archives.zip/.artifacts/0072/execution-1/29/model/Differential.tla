---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Get(delta) == LET F[i \in {0,1}] == IF i=0 THEN delta ELSE F[1] IN F
Init == x=(Get(7)[0])
Next == UNCHANGED x
====