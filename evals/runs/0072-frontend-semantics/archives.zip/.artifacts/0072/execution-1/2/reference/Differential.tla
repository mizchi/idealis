---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Bad == ENABLED ([](x=0))
Init == x=0
Next == x'=x
====