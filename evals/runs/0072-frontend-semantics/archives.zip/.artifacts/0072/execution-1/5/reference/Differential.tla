---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Bad == ([](x=0)) = TRUE
Init == x=0
Next == x'=x
====