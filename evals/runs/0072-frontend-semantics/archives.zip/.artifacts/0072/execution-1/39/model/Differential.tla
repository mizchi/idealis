---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
T0(limit) == [](x<limit)
T1(limit) == T0(limit) /\ T0(limit)
T2(limit) == T1(limit) /\ T1(limit)
T3(limit) == T2(limit) /\ T2(limit)
T4(limit) == T3(limit) /\ T3(limit)
T5(limit) == T4(limit) /\ T4(limit)
Init == x=0
Next == x'=(x+1)%4
Live == T5(4)
====