---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
A0(v) == x'=v
A1(v) == A0(v) \/ A0(v)
A2(v) == A1(v) \/ A1(v)
A3(v) == A2(v) \/ A2(v)
A4(v) == A3(v) \/ A3(v)
A5(v) == A4(v) \/ A4(v)
A6(v) == A5(v) \/ A5(v)
Init == x=0
Next == A6((x+1)%4)
====