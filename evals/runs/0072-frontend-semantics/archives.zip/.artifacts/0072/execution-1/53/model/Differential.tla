---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
A0(v) == x'=v
A1(v) == A0(v) \/ A0(v)
A2(v) == A1(v) \/ A1(v)
T(limit) == []<>(x<limit)
Live == T(6) /\ T(6)
Init == x=0
Next == A2((x+1)%6)
Safe == x<5
====