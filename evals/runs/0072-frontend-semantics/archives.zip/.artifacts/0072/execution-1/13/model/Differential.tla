---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
P(a) == a'
Good == P(x)
Init == x=0
Next == x'=x
====