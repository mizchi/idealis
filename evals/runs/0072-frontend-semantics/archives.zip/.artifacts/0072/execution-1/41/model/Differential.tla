---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
F[i \in 0..15] == IF i=0 THEN 1 ELSE IF i=1 THEN 1 \div 0 ELSE F[0]
Alias == F
Id(f) == f
Init == x=0
Next == x'=(x+Id(Alias)[0])%4
====