---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Good == LET P(a) == a' IN P(x)
Init == x=0
Next == x'=x
====