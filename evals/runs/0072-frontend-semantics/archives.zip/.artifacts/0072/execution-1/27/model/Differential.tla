---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
F[i \in {0,1}] == IF i=0 THEN 7 ELSE F[1]
Alias == F
Id(f) == f
Init == x=(Id(Alias)[0])
Next == UNCHANGED x
====