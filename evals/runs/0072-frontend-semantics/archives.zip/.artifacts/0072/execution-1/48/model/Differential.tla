---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
A0(v) == x'=v
A1(v) == A0(v) \/ A0(v)
T(limit) == []<>(x<limit)
Live == T(4) /\ T(4)
Init == x=0
Next == A1((x+1)%4)
Safe == x<4
====