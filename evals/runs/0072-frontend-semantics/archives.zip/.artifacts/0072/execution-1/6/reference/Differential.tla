---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Bad == [x'=x]_(x')
Init == x=0
Next == x'=x
====