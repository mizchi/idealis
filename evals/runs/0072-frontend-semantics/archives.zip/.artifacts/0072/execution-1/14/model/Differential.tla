---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
P(a) == ENABLED a
Good == P(x'=x)'
Init == x=0
Next == x'=x
====