---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
P(a) == a'
Q(b) == P(b)
Bad == Q(x')
Init == x=0
Next == x'=x
====