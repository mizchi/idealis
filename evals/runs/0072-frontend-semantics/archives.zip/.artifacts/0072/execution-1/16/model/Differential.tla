---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
RECURSIVE P(_)
P(a) == IF TRUE THEN a ELSE P(a)
Good == P(x')
Init == x=0
Next == x'=x
====