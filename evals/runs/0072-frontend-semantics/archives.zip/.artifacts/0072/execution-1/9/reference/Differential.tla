---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Bad == LET P(a) == a' IN P(x')
Init == x=0
Next == x'=x
====