---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
A0(v) == x'=v
A1(v) == A0(v) \/ A0(v)
A2(v) == A1(v) \/ A1(v)
A3(v) == A2(v) \/ A2(v)
A4(v) == A3(v) \/ A3(v)
T(limit) == []<>(x<limit)
Live == T(4) /\ T(4)
Init == x=0
Next == A4((x+1)%4)
Safe == x<3
====