---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Bad == WF_(x')(x'=x)
Init == x=0
Next == x'=x
====