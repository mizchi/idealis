---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
T(p) == []<>p
Both(p) == T(p) /\ T(p)
Init == x=0
Next == x'=(x+1)%3
Live == Both(x=0)
====