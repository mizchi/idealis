---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
F[i \in 0..7] == IF i=0 THEN 7 ELSE IF i=1 THEN 1 \div 0 ELSE F[0]
Alias == F
Id(f) == f
Init == x=(Alias[0])
Next == UNCHANGED x
ValueSafe == x=7
====