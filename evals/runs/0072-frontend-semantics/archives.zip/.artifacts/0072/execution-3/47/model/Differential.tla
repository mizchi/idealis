---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
F[i \in {0,1}] == IF i=0 THEN x ELSE F[1]
Id(f) == f
Init == x=0
Next == x'=(x+1)%3 /\ Id(F)[0]=x /\ Id(F')[0]=x'
ValueSafe == x \in 0..2
====