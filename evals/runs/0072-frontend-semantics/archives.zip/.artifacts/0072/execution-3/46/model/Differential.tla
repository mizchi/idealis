---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
F[i \in 0..3] == IF i=0 THEN 0 ELSE F[i-1]+1
Alias == F
Id(f) == f
Init == x=(Id(Alias))
Next == UNCHANGED x
ValueSafe == DOMAIN x=(0..3) /\ x[0]=0 /\ x[1]=1 /\ x[2]=2 /\ x[3]=3
====