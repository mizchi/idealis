use crate::ir::{Expression, SafetyProgram, Scalar, TemporalFormula};
use crate::safety_expressions::{EvalContext, register_branch_memberships};
use crate::safety_values::Arena;
use crate::{CoreError, Value};
use std::collections::HashMap;

pub(crate) struct PreparedProgram<'a> {
    slots: HashMap<usize, usize>,
    values: Vec<&'a Value>,
    plans: HashMap<usize, ScalarPlan>,
}

impl<'a> PreparedProgram<'a> {
    pub fn new(program: &'a SafetyProgram) -> Self {
        let mut roots = Vec::new();
        register_branch_memberships(&program.initial, &mut |expression| roots.push(expression));
        register_branch_memberships(&program.next, &mut |expression| roots.push(expression));
        roots.extend(
            program
                .invariants
                .iter()
                .chain(&program.assumptions)
                .chain(&program.initial_properties)
                .chain(&program.action_properties)
                .chain(&program.constraints)
                .chain(&program.action_constraints)
                .map(|predicate| &predicate.expression),
        );
        let mut formulas = program
            .properties
            .iter()
            .map(|property| &property.formula)
            .chain(&program.fairness)
            .collect::<Vec<_>>();
        while let Some(formula) = formulas.pop() {
            match formula {
                TemporalFormula::Atom { expression } => roots.push(expression),
                TemporalFormula::Not { formula }
                | TemporalFormula::Always { formula }
                | TemporalFormula::Eventually { formula } => formulas.push(formula),
                TemporalFormula::And { left, right } | TemporalFormula::Or { left, right } => {
                    formulas.extend([left.as_ref(), right.as_ref()])
                }
                TemporalFormula::Forall { bounds, formula }
                | TemporalFormula::Exists { bounds, formula } => {
                    for bound in bounds {
                        roots.extend(bound.domain.children());
                    }
                    formulas.push(formula);
                }
            }
        }
        Self::from_roots(roots)
    }

    pub fn from_roots(mut roots: Vec<&'a Expression>) -> Self {
        let mut prepared = Self {
            slots: HashMap::new(),
            values: Vec::new(),
            plans: HashMap::new(),
        };
        let mut expressions = Vec::new();
        while let Some(expression) = roots.pop() {
            expressions.push(expression);
            if let Expression::Data { value } = expression {
                let address = std::ptr::from_ref(expression) as usize;
                if let std::collections::hash_map::Entry::Vacant(entry) =
                    prepared.slots.entry(address)
                {
                    entry.insert(prepared.values.len());
                    prepared.values.push(value);
                }
            }
            if let Expression::Enabled {
                branches,
                subscript,
            } = expression
            {
                register_branch_memberships(branches, &mut |expression| roots.push(expression));
                roots.extend(subscript.iter().map(Box::as_ref));
            }
            roots.extend(expression.children());
        }
        for expression in expressions {
            if let Some(plan) = ScalarPlan::compile(expression, &prepared) {
                prepared
                    .plans
                    .insert(std::ptr::from_ref(expression) as usize, plan);
            }
        }
        prepared
    }

    pub fn plan(&self, expression: &Expression) -> Option<&ScalarPlan> {
        self.plans.get(&(std::ptr::from_ref(expression) as usize))
    }

    pub fn slot(&self, expression: &Expression) -> Option<usize> {
        self.slots
            .get(&(std::ptr::from_ref(expression) as usize))
            .copied()
    }

    pub fn value(&self, slot: usize) -> &'a Value {
        self.values[slot]
    }

    pub fn len(&self) -> usize {
        self.values.len()
    }
}

#[derive(Clone, Copy)]
pub(crate) enum Operand {
    Literal(Scalar),
    Read { slot: usize, next: bool },
    Bound(usize),
    Old,
    Constant(usize),
}

impl Operand {
    fn compile(expression: &Expression, prepared: &PreparedProgram<'_>) -> Option<Self> {
        Some(match expression {
            Expression::Literal { value } => Self::Literal(*value),
            Expression::Read { slot, next } => Self::Read {
                slot: *slot,
                next: *next,
            },
            Expression::Bound { slot } => Self::Bound(*slot),
            Expression::Old => Self::Old,
            Expression::Data { .. } => Self::Constant(prepared.slot(expression)?),
            _ => return None,
        })
    }

    fn eval(self, context: EvalContext<'_>, arena: &mut Arena) -> Result<Scalar, CoreError> {
        match self {
            Self::Literal(value) => Ok(value),
            Self::Read { slot, next } => context.read(slot, next),
            Self::Bound(slot) => context
                .locals
                .get(slot)
                .copied()
                .ok_or_else(|| CoreError::protocol("Unbound quantified variable")),
            Self::Old => context
                .old
                .ok_or_else(|| CoreError::protocol("Unbound EXCEPT @")),
            Self::Constant(slot) => arena.constant(slot),
        }
    }
}

pub(crate) enum IntOperator {
    Add,
    Sub,
    Mul,
    Lt,
    Le,
    Gt,
    Ge,
}

pub(crate) enum ScalarPlan {
    Integer(IntOperator, Operand, Operand),
    Equal(bool, Operand, Operand),
    At(Operand, Operand),
    Not(Operand),
    Neg(Operand),
}

impl ScalarPlan {
    fn compile(expression: &Expression, prepared: &PreparedProgram<'_>) -> Option<Self> {
        let operand = |expression| Operand::compile(expression, prepared);
        Some(match expression {
            Expression::Add { left, right }
            | Expression::Sub { left, right }
            | Expression::Mul { left, right }
            | Expression::Lt { left, right }
            | Expression::Le { left, right }
            | Expression::Gt { left, right }
            | Expression::Ge { left, right } => Self::Integer(
                match expression {
                    Expression::Add { .. } => IntOperator::Add,
                    Expression::Sub { .. } => IntOperator::Sub,
                    Expression::Mul { .. } => IntOperator::Mul,
                    Expression::Lt { .. } => IntOperator::Lt,
                    Expression::Le { .. } => IntOperator::Le,
                    Expression::Gt { .. } => IntOperator::Gt,
                    _ => IntOperator::Ge,
                },
                operand(left)?,
                operand(right)?,
            ),
            Expression::Eq { left, right } | Expression::Ne { left, right } => Self::Equal(
                matches!(expression, Expression::Eq { .. }),
                operand(left)?,
                operand(right)?,
            ),
            Expression::At { target, key } => Self::At(operand(target)?, operand(key)?),
            Expression::Not { argument } => Self::Not(operand(argument)?),
            Expression::Neg { argument } => Self::Neg(operand(argument)?),
            _ => return None,
        })
    }

    pub fn eval(&self, context: EvalContext<'_>, arena: &mut Arena) -> Result<Scalar, CoreError> {
        Ok(match self {
            Self::Integer(operator, left, right) => {
                let left = left.eval(context, arena)?.integer()?;
                let right = right.eval(context, arena)?.integer()?;
                match operator {
                    IntOperator::Lt => Scalar::Bool(left < right),
                    IntOperator::Le => Scalar::Bool(left <= right),
                    IntOperator::Gt => Scalar::Bool(left > right),
                    IntOperator::Ge => Scalar::Bool(left >= right),
                    _ => Scalar::Int(
                        match operator {
                            IntOperator::Add => left.checked_add(right),
                            IntOperator::Sub => left.checked_sub(right),
                            _ => left.checked_mul(right),
                        }
                        .ok_or_else(|| CoreError::protocol("Safety integer overflow"))?,
                    ),
                }
            }
            Self::Equal(equal, left, right) => {
                let left = left.eval(context, arena)?;
                let right = right.eval(context, arena)?;
                Scalar::Bool(arena.equal(left, right)? == *equal)
            }
            Self::At(target, key) => {
                let target = target.eval(context, arena)?;
                let key = key.eval(context, arena)?;
                arena.at(target, key)?
            }
            Self::Not(argument) => Scalar::Bool(!argument.eval(context, arena)?.boolean()?),
            Self::Neg(argument) => Scalar::Int(
                argument
                    .eval(context, arena)?
                    .integer()?
                    .checked_neg()
                    .ok_or_else(|| CoreError::protocol("Safety integer overflow"))?,
            ),
        })
    }
}

#[cfg(test)]
mod plan_tests {
    use super::PreparedProgram;
    use crate::Value;
    use crate::ir::{Expression, Scalar};
    use crate::safety_expressions::EvalContext;
    use crate::safety_values::Arena;
    use serde_json::json;

    fn evaluate(
        expression: &Expression,
        context: EvalContext<'_>,
        prepared: bool,
    ) -> (Result<Value, (String, String)>, u32) {
        let program = PreparedProgram::from_roots(vec![expression]);
        let mut arena = if prepared {
            Arena::with_prepared(1000, &program)
        } else {
            Arena::new(1000)
        };
        let result = expression
            .eval(context, &mut arena)
            .and_then(|value| arena.portable(value));
        (
            result.map_err(|error| (error.code.to_string(), error.message)),
            arena.work,
        )
    }

    #[test]
    fn typed_leaf_instructions_match_expected_values_and_interpreter_work() {
        let left = json!({"op":"read","slot":0,"next":false});
        let right = json!({"op":"bound","slot":0});
        let context = EvalContext {
            current: &[Scalar::Int(6)],
            next: &[Some(Scalar::Int(9))],
            locals: &[Scalar::Int(2)],
            old: Some(Scalar::Int(4)),
            prime: false,
        };
        for (operator, expected) in [
            ("add", Value::Int("8".into())),
            ("sub", Value::Int("4".into())),
            ("mul", Value::Int("12".into())),
            ("lt", Value::Bool(false)),
            ("le", Value::Bool(false)),
            ("gt", Value::Bool(true)),
            ("ge", Value::Bool(true)),
            ("eq", Value::Bool(false)),
            ("ne", Value::Bool(true)),
        ] {
            let expression: Expression =
                serde_json::from_value(json!({"op":operator,"left":left,"right":right})).unwrap();
            let program = PreparedProgram::from_roots(vec![&expression]);
            assert!(program.plan(&expression).is_some(), "{operator}");
            let actual = evaluate(&expression, context, true);
            assert_eq!(actual.0, Ok(expected), "{operator}");
            assert_eq!(actual, evaluate(&expression, context, false));
            assert_eq!(
                evaluate(
                    &expression,
                    EvalContext {
                        prime: true,
                        ..context
                    },
                    true
                ),
                evaluate(
                    &expression,
                    EvalContext {
                        prime: true,
                        ..context
                    },
                    false
                )
            );
        }
        for (input, expected) in [
            (
                json!({"op":"neg","argument":{"op":"old"}}),
                Value::Int("-4".into()),
            ),
            (
                json!({"op":"not","argument":{"op":"literal","value":{"type":"bool","value":true}}}),
                Value::Bool(false),
            ),
            (
                json!({"op":"at","target":{"op":"data","value":{"type":"list","value":[{"type":"int","value":"10"},{"type":"int","value":"20"}]}},"key":{"op":"literal","value":{"type":"int","value":"2"}}}),
                Value::Int("20".into()),
            ),
        ] {
            let expression: Expression = serde_json::from_value(input).unwrap();
            assert!(
                PreparedProgram::from_roots(vec![&expression])
                    .plan(&expression)
                    .is_some()
            );
            let actual = evaluate(&expression, context, true);
            assert_eq!(actual.0, Ok(expected));
            assert_eq!(actual, evaluate(&expression, context, false));
        }
    }

    #[test]
    fn typed_plans_preserve_error_order_overflow_and_fallback() {
        for operator in ["add", "sub", "mul", "lt", "le", "gt", "ge"] {
            let expression: Expression = serde_json::from_value(json!({"op":operator,"left":{"op":"literal","value":{"type":"bool","value":true}},"right":{"op":"data","value":{"type":"int","value":"invalid"}}})).unwrap();
            let actual = evaluate(&expression, EvalContext::new(&[], &[]), true);
            assert_eq!(
                actual.0,
                Err(("protocol".into(), "Expected an integer".into()))
            );
            assert_eq!(
                actual,
                evaluate(&expression, EvalContext::new(&[], &[]), false)
            );
        }
        for input in [
            json!({"op":"add","left":{"op":"literal","value":{"type":"int","value":"2147483647"}},"right":{"op":"literal","value":{"type":"int","value":"1"}}}),
            json!({"op":"neg","argument":{"op":"literal","value":{"type":"int","value":"-2147483648"}}}),
            json!({"op":"eq","left":{"op":"data","value":{"type":"string","value":"text"}},"right":{"op":"literal","value":{"type":"bool","value":false}}}),
            json!({"op":"at","target":{"op":"old"},"key":{"op":"bound","slot":5}}),
            json!({"op":"add","left":{"op":"read","slot":0,"next":true},"right":{"op":"old"}}),
        ] {
            let expression: Expression = serde_json::from_value(input).unwrap();
            let actual = evaluate(&expression, EvalContext::new(&[], &[]), true);
            assert!(actual.0.is_err());
            assert_eq!(
                actual,
                evaluate(&expression, EvalContext::new(&[], &[]), false)
            );
        }
        let fallback: Expression = serde_json::from_value(json!({"op":"if","condition":{"op":"literal","value":{"type":"bool","value":false}},"consequent":{"op":"data","value":{"type":"int","value":"invalid"}},"alternative":{"op":"add","left":{"op":"literal","value":{"type":"int","value":"1"}},"right":{"op":"literal","value":{"type":"int","value":"2"}}}})).unwrap();
        assert!(
            PreparedProgram::from_roots(vec![&fallback])
                .plan(&fallback)
                .is_none()
        );
        assert_eq!(
            evaluate(&fallback, EvalContext::new(&[], &[]), true),
            (Ok(Value::Int("3".into())), 0)
        );
    }
}
